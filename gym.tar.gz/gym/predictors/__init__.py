from stml_mft_china_eq.statarb.gym.predictors.predictors_single import get_default_kwargs_single, get_default_param_grid_single, make_predictor_single
from stml_mft_china_eq.statarb.gym.predictors.predictor_linear import ElasticNet, Ridge, Lasso, ZeroPredictor, MMElasticNet, MMRidge, MMLasso, RobustMMElasticNet, RobustMMRidge, RobustMMLasso
from stml_mft_china_eq.statarb.gym.predictors.predictor_tree import XGBRegressor, LGBRegressor, RFRegressor
from stml_mft_china_eq.statarb.gym.predictors.predictor_tod_moe import TODMOEPredictor
PREFIX_CODE_TODMOE = "todmoe"


def get_default_kwargs(predictor_model_code):
    if not predictor_model_code.startswith(PREFIX_CODE_TODMOE):
        return get_default_kwargs_single(predictor_model_code)
    else:
        base_predictor_model_code = predictor_model_code[len(PREFIX_CODE_TODMOE):]
        default_kwargs = get_default_kwargs_single(base_predictor_model_code).copy()
        default_kwargs.update({
            "choice_kernel": "gaussian",
            "sigma_kernel": 1.0,
            "base_predictor_model_code": base_predictor_model_code,
        })
        return default_kwargs


def get_default_param_grid(predictor_model_code):
    if not predictor_model_code.startswith(PREFIX_CODE_TODMOE):
        return get_default_param_grid_single(predictor_model_code)
    else:
        base_predictor_model_code = predictor_model_code[len(PREFIX_CODE_TODMOE):]
        default_param_grid = get_default_param_grid_single(base_predictor_model_code).copy()
        default_param_grid.update({
            "sigma_kernel": [0.7, 1.0, 1.2],
        })
        return default_param_grid


def make_predictor(predictor_model_code, **kwargs):
    if not predictor_model_code.startswith(PREFIX_CODE_TODMOE):
        return make_predictor_single(predictor_model_code, **kwargs)
    else:
        return make_predictor_todmoe(predictor_model_code, **kwargs)


def make_predictor_todmoe(predictor_model_code, **kwargs_base_predictor):
    if not predictor_model_code.startswith(PREFIX_CODE_TODMOE):
        raise ValueError("predictor_model_code={0}, not startswith {1}".format(predictor_model_code, PREFIX_CODE_TODMOE))
    if "base_predictor_model_code" not in kwargs_base_predictor:
        kwargs_base_predictor["base_predictor_model_code"] = predictor_model_code[len(PREFIX_CODE_TODMOE):]
    return TODMOEPredictor(**kwargs_base_predictor)
