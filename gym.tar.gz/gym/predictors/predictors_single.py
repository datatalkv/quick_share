from stml_mft_china_eq.statarb.gym.predictors.predictor_linear import ElasticNet, Ridge, Lasso, ZeroPredictor, MMElasticNet, MMRidge, MMLasso, RobustMMElasticNet, RobustMMRidge, RobustMMLasso
from stml_mft_china_eq.statarb.gym.predictors.predictor_tree import XGBRegressor, LGBRegressor, RFRegressor


def get_default_kwargs_single(predictor_model_code):
    if predictor_model_code in ['ridge', 'lasso', 'elasticnet', "wtridge", "wtlasso", "wtelasticnet"]:
        return {
            "fit_intercept":False
        }
    if predictor_model_code in ['mmridge', 'mmlasso', 'mmelasticnet']:
        return {
            "fit_intercept":False,
            "type_mm":"mom"
        }
    if predictor_model_code in ['robmmridge', 'robmmlasso', 'robmmelasticnet']:
        return {}
    if predictor_model_code == 'xgb':
        return {
            "n_estimators": 100,
            "max_depth": 5,
            "reg_alpha": 0,
            "subsample": 0.7,
            "colsample_bytree": 0.7,
            "n_jobs": 10,
        }
    if predictor_model_code == 'lgb':
        # return {
            # "n_estimators": 100,
            # "max_bin": 63,
            # "max_depth": 5,
            # "num_leaves": 32,
            # "reg_alpha": 0,
            # "bagging_fraction": 0.7,
            # "feature_fraction": 0.7,
            # "subsample": 0.9,
            # "n_jobs": 10,
        # }
        return {
            'n_estimators': 100,
            # 'learning_rate': 0.2,
            'max_bin': 63,
            'num_leaves': 900,
            'max_depth': 7,
            'min_data_in_leaf': 1500,
            'lambda_l1': 5,
            'lambda_l2': 60,
            'min_gain_to_split': 0.05,
            'bagging_fraction': 0.9,
            'bagging_freq': 1,
            'feature_fraction': 0.9,
            'n_jobs': 10,
        }

    if predictor_model_code == 'rf':
        return {
            "n_estimators": 100,
            "max_depth": 7,
            "bootstrap": True,
            "n_jobs": 10,
            "min_weight_fraction_leaf": 0.01,
        }
    raise NotImplementedError()


def get_default_param_grid_single(predictor_model_code):
    if predictor_model_code in ['ridge', 'lasso', 'wtridge', 'wtlasso', 'mmridge', 'mmlasso', 'robmmridge', 'robmmlasso']:
        return {
            "alpha": [0.01, 0.1, 0.5, 1.0, 5.0, 10.0, 100.0]
        }
    if predictor_model_code in ['elasticnet', 'wtelasticnet', 'mmelasticnet', 'robmmelasticnet']:
        return {
            "alpha": [0.1, 1.0, 10.0, 100.0],
            "l1_ratio": [0.2, 0.4, 0.6, 0.8],
        }
    if predictor_model_code == 'xgb':
        return {
            "learning_rate": [0.005, 0.05],
            "gamma": [1, 10, 100],
            "reg_lambda": [1, 10],
        }
    if predictor_model_code == 'lgb':
        return {
            "learning_rate": [0.05, 0.1, 0.2],
            # "min_split_gain": [0.1, 1, 10, 100],
        }
    if predictor_model_code == 'rf':
        return {
            "max_depth": [10, 20],
            'max_features': ["auto", "sqrt"],
            'min_samples_leaf': [0.0005, 0.005],
            'min_samples_split': [0.005, 0.05],
        }
    raise NotImplementedError()


def make_predictor_single(predictor_model_code, **kwargs):
    if predictor_model_code.lower() == "ridge":
        return Ridge(**kwargs)
    elif predictor_model_code.lower() == "lasso":
        return Lasso(**kwargs)
    elif predictor_model_code.lower() == "elasticnet":
        return ElasticNet(**kwargs)
    elif predictor_model_code.lower() == "mmridge":
        return MMRidge(**kwargs)
    elif predictor_model_code.lower() == "mmlasso":
        return MMLasso(**kwargs)
    elif predictor_model_code.lower() == "mmelasticnet":
        return MMElasticNet(**kwargs)
    elif predictor_model_code.lower() == "robmmridge":
        return RobustMMRidge(**kwargs)
    elif predictor_model_code.lower() == "robmmlasso":
        return RobustMMLasso(**kwargs)
    elif predictor_model_code.lower() == "robmmelasticnet":
        return RobustMMElasticNet(**kwargs)
    elif predictor_model_code.lower() == "xgb":
        return XGBRegressor(**kwargs)
    elif predictor_model_code.lower() == "lgb":
        return LGBRegressor(**kwargs)
    elif predictor_model_code.lower() == "rf":
        return RFRegressor(**kwargs)
    else:
        raise NotImplementedError()
