# -*- coding: utf-8 -*-
"""
Predictor wrapper of individual predictor to time-of-day (TOD) mixture-of-experts (MOE) ensemble.
"""
import logging
import pandas as pd
import numpy as np

from stml_mft_china_eq.statarb.gym.predictors.predictors_single import make_predictor_single


def get_weights_tod(i_loc_tod=0, n_intervals_daily=1440, sigma=1.0, choice_kernel="gaussian", do_normalize=False):
    sin_tod = np.sin(2 * np.pi * np.arange(n_intervals_daily) / n_intervals_daily)
    cos_tod = np.cos(2 * np.pi * np.arange(n_intervals_daily) / n_intervals_daily)
    sin_loc_tod, cos_loc_tod = sin_tod[i_loc_tod], cos_tod[i_loc_tod]
    if choice_kernel == "gaussian":
        wt = np.exp(-0.5 * ((sin_tod - sin_loc_tod)**2 + (cos_tod - cos_loc_tod) **2) / sigma**2)
    elif choice_kernel == "laplacian":
        wt = np.exp(-0.5 * (np.abs(sin_tod - sin_loc_tod) + np.abs(cos_tod - cos_loc_tod)) / sigma)
    else:
        raise NotImplementedError()
    if do_normalize:
        wt = wt / np.sum(wt)
    return wt


class TODMOEPredictor:
    def __init__(
        self,
        n_intervals_daily=1440,
        list_loc_tod_moe=None,
        choice_kernel="gaussian",
        sigma_kernel=1.0,
        base_predictor_model_code="wtridge",
        **kwargs_base_predictor
    ):
        """TOD MOE predictor"""
        self.n_intervals_daily = n_intervals_daily
        if list_loc_tod_moe is None:
            list_loc_tod_moe = list(range(0, n_intervals_daily, int(n_intervals_daily/4)))
        self.n_tod_moe = len(list_loc_tod_moe)
        self.list_loc_tod_moe = list_loc_tod_moe
        self.choice_kernel = choice_kernel
        self.sigma_kernel = sigma_kernel
        mat_moe_wt = np.concatenate([
            get_weights_tod(i_loc_tod=loc_tod_moe, n_intervals_daily=n_intervals_daily, sigma=self.sigma_kernel, choice_kernel=self.choice_kernel, do_normalize=False).reshape([-1,1])
            for loc_tod_moe in self.list_loc_tod_moe], 1)
        self.mat_moe_wt = mat_moe_wt / np.sum(mat_moe_wt, 1, keepdims=True)
        self._base_predictor_model_code = base_predictor_model_code
        self._kwargs_base_predictor = kwargs_base_predictor
        self.list_predictors = [
            make_predictor_single(
                self._base_predictor_model_code, **self._kwargs_base_predictor)
            for _ in range(self.n_tod_moe)
        ]

    def intervals2sample_weights(self, intervals):
        if (intervals<0).any() or (intervals>=self.n_intervals_daily).any():
            raise ValueError("The range of intervals are out of [0,n_intervals_daily)")
        sample_weights = self.mat_moe_wt[intervals.astype("int32"), :]
        return sample_weights

    def fit(self, x, intervals, y):
        """
        Args:
            X: (n_samples, n_dim_x), training features.
            intervals: (n_samples,), training intervals, with each entry being in range(n_intervals_daily).
            y: (n_samples,) or (n_samples, n_dim_y), training targets.
        """
        sample_weights = self.intervals2sample_weights(intervals.reshape([-1]))
        if len(set([x.shape[0], intervals.shape[0], y.shape[0], sample_weights.shape[0]])) > 1:
            raise ValueError("x.shape={0}, intervals.shape={1}, y.shape={2}, sample_weights.shape={3}, contradicted!".format(
                x.shape, intervals.shape, y.shape, sample_weights.shape))
        for i_tod_moe in range(self.n_tod_moe):
            try:
                self.list_predictors[i_tod_moe].fit(x, y, sample_weight=sample_weights[:,i_tod_moe])
            except TypeError:
                raise TypeError("The base_predictor_model_code={} currently cannot support sample_weight. Consequently the TODMOEPredictor cannot take it as the base predictor. Please choose another base predictor then.")
        return self

    def predict(self, x, intervals):
        """
        Args:
            X: (n_samples, n_dim_x), training features.
            intervals: (n_samples,), training intervals, with each entry being in range(n_intervals_daily).
        """
        sample_weights = self.intervals2sample_weights(intervals.reshape([-1]))
        if len(set([x.shape[0], intervals.shape[0], sample_weights.shape[0]])) > 1:
            raise ValueError("x.shape={0}, intervals.shape={1}, sample_weights.shape={2}, contradicted!".format(
                x.shape, intervals.shape, sample_weights.shape))
        yhats = np.concatenate([
            self.list_predictors[i_tod_moe].predict(x).reshape([-1,1])
            for i_tod_moe in range(self.n_tod_moe)
        ], 1)
        yhat = np.sum(sample_weights * yhats, 1)
        return yhat
