# -*- coding: utf-8 -*-
"""
Robustly weighted linear predictors (still under revision and testing @ 20210824)
"""
import logging
import pandas as pd
import numpy as np
import cvxpy as cp
from collections import OrderedDict
from predictor_linear import ElasticNet, Ridge, Lasso, ZeroPredictor, MMElasticNet, MMRidge, MMLasso

def noncenter_corrcoef(a, b):
    return np.mean(a.reshape([-1]) * b.reshape([-1])) / (np.sqrt(np.mean(a**2)) * np.sqrt(np.mean(b**2)))


def adjust_positive_scale_by_global(yhat, y, EPSILON=1e-20):
    """min_{a>=0} (a * yhat - y)**2"""
    yhat = yhat.reshape([-1])
    y = y.reshape([-1])
    scale_a = np.maximum(np.mean(yhat*y) / (np.mean(yhat**2) + EPSILON), 0.0)
    if not np.isfinite(scale_a):
        scale_a = 0.0
    return scale_a


class EnvLinear:
    """Environment-sensitive linear regressors"""
    def __init__(self, str_linear_regressor, **init_kwargs_per_env):
        if str_linear_regressor == "ridge":
            self.linear_regressor = Ridge
        elif str_linear_regressor == "lasso":
            self.linear_regressor = Lasso
        elif str_linear_regressor == "elasticnet":
            self.linear_regressor = ElasticNet
        elif str_linear_regressor == "mmridge":
            self.linear_regressor = MMRidge
        elif str_linear_regressor == "mmlasso":
            self.linear_regressor = MMLasso
        elif str_linear_regressor == "mmelasticnet":
            self.linear_regressor = MMElasticNet
        else:
            raise NotImplementedError()

        init_kwargs_per_env.update({"fit_intercept": False})
        self.init_kwargs_per_env = init_kwargs_per_env
        self.env_id2model = {}
        self.env_id2xx = {}
        self.env_id2xy = {}
        self.env_id2yy = {}
        self.env_id2ee = {}

    def fit_one_env(self, x, y, env_id=None, **fit_kwargs):
        if env_id is None:
            # new env, new id
            env_id = len(self.env_id2model)
            assert env_id not in self.env_id2model
        m = self.env_id2model.get(env_id, self.linear_regressor(**self.init_kwargs_per_env))
        m.fit(x, y, **fit_kwargs)
        self.env_id2model[env_id] = m

        # store some statistics for later usage
        n_samp = x.shape[0]
        pre_compute = fit_kwargs.get("pre_compute", None)
        if pre_compute is not None:
            self.env_id2xx[env_id] = pre_compute / n_samp
        else:
            self.env_id2xx[env_id] = np.dot(x.T, x) / n_samp
        self.env_id2xy[env_id] = np.dot(x.T, y) / n_samp
        self.env_id2yy[env_id] = np.dot(y.T, y) / n_samp
        err = m.predict(x).reshape([-1]) - y.reshape([-1])
        self.env_id2ee[env_id] = np.dot(err.T, err) / n_samp

    def get_weighted_mean_w(self):
        xx = 0
        xy = 0
        for env_id in self.env_id2model.keys():
            m = self.env_id2model[env_id]
            smoothed_xx = self.env_id2xx[env_id] + m.alpha * (1.0 - m.l1_ratio) * np.eye(self.env_id2xx[env_id].shape[0])
            xx += smoothed_xx / self.env_id2ee[env_id]
            xy += np.dot(smoothed_xx, self.env_id2model[env_id].coef_.reshape([-1,1])) / self.env_id2ee[env_id]
            # xy += self.env_id2xy[env_id] / self.env_id2ee[env_id]
        return np.linalg.solve(xx, xy)

    def get_MAP_mean_w(self):
        w = np.mean(np.concatenate([
                self.env_id2model[env_id].coef_.reshape([-1,1])
                for env_id in self.env_id2model.keys()
            ], 1), 1, keepdims=True)
        return w

    def get_irm_w(self, lamb_irm=0.0000001):
        xx = 0
        xy = 0
        for env_id in self.env_id2model.keys():
            xx += self.env_id2xx[env_id] + lamb_irm * np.dot(self.env_id2xy[env_id], self.env_id2xy[env_id].T)
            xy += (1.0 + lamb_irm * self.env_id2yy[env_id]) * self.env_id2xy[env_id]
        return np.linalg.solve(xx, xy)

    def get_irm_weighted_w(self, lamb_irm=1.0):#0.01):
        xx = 0
        xy = 0
        for env_id in self.env_id2model.keys():
            xx += self.env_id2xx[env_id] / self.env_id2ee[env_id] + lamb_irm * np.dot(self.env_id2xy[env_id], self.env_id2xy[env_id].T) / self.env_id2ee[env_id]**2
            xy += self.env_id2xy[env_id] / self.env_id2ee[env_id] + lamb_irm * self.env_id2yy[env_id] * self.env_id2xy[env_id] / self.env_id2ee[env_id]**2
        return np.linalg.solve(xx, xy)


def gen_data(n_env=100, n_samp_per_env=1000, n_samp_per_env_train=10, n_dim_x=10):
    all_x_train, all_y_train= [], []
    all_x_test, all_y_test = [], []
    w_true_global = np.random.randn(n_dim_x, 1)
    all_w_true = []
    for i_env in range(n_env):
        x = np.random.randn(n_samp_per_env, n_dim_x)
        w_true = np.random.rand() * np.random.randn(n_dim_x, 1) + w_true_global
        y = np.dot(x, w_true) + 50 * (1+np.random.rand()) * np.random.randn(n_samp_per_env, 1) + np.random.randn()
        all_x_train.append(x[:n_samp_per_env_train])
        all_y_train.append(y[:n_samp_per_env_train])
        all_x_test.append(x[n_samp_per_env_train:])
        all_y_test.append(y[n_samp_per_env_train:])
        all_w_true.append(w_true)
    return all_x_train, all_y_train, all_x_test, all_y_test, all_w_true, w_true_global


if __name__ == "__main__":
    n_env = 100
    n_samp_per_env = 10000
    n_samp_per_env_train = 10
    n_dim_x = 50
    all_x_train, all_y_train, all_x_test, all_y_test, all_w_true, w_true_global = gen_data(
        n_env=n_env, n_samp_per_env=n_samp_per_env, n_samp_per_env_train=n_samp_per_env_train, n_dim_x=n_dim_x)
    m = EnvLinear(str_linear_regressor="elasticnet", fit_intercept=False)
    for env_id in range(n_env):
        m.fit_one_env(all_x_train[env_id], all_y_train[env_id], env_id)

    m_single = Ridge(fit_intercept=False)
    m_single.fit(
        np.concatenate(all_x_train, 0),
        np.concatenate(all_y_train, 0),
    )

    weighted_w = m.get_weighted_mean_w()
    mean_w = m.get_MAP_mean_w()
    irm_w = m.get_irm_w()
    irm_wt_w = m.get_irm_weighted_w()
    single_w = m_single.coef_.reshape([-1,1])

    data_yhat = OrderedDict()
    scales = OrderedDict()
    for mode, xx, yy in zip(["train", "test"], [all_x_train, all_x_test], [all_y_train, all_y_test]):
        data_yhat["true@"+mode] = np.concatenate(yy, 1)
        data_yhat["ind_w@"+mode] = np.concatenate([
            np.dot(xx[env_id], m.env_id2model[env_id].coef_.reshape([-1,1]))
            for env_id in range(n_env)], 1)
        data_yhat["weighted_w@"+mode]= np.concatenate([
            np.dot(xx[env_id], weighted_w)
            for env_id in range(n_env)], 1)
        data_yhat["mean_w@"+mode] = np.concatenate([
            np.dot(xx[env_id], mean_w)
            for env_id in range(n_env)], 1)
        data_yhat["irm_w@"+mode] = np.concatenate([
            np.dot(xx[env_id], irm_w)
            for env_id in range(n_env)], 1)
        # data_yhat["irm_wt_w@"+mode] = np.concatenate([
            # np.dot(xx[env_id], irm_wt_w)
        #     for env_id in range(n_env)], 1)
        data_yhat["single_w@"+mode] = np.concatenate([
            np.dot(xx[env_id], single_w)
            for env_id in range(n_env)], 1)
        if mode == "train":
            # for str_type in ["ind_w", "weighted_w", "mean_w", "irm_w", "irm_wt_w", "single_w"]:
            for str_type in ["ind_w", "weighted_w", "mean_w", "irm_w", "single_w"]:
                scales[str_type] = adjust_positive_scale_by_global(data_yhat[str_type+"@train"], data_yhat["true@train"])

    for mode in ["train", "test"]:
        # for str_type in ["ind_w", "weighted_w", "mean_w", "irm_w", "irm_wt_w", "single_w"]:
        for str_type in ["ind_w", "weighted_w", "mean_w", "irm_w", "single_w"]:
            data_yhat["scaled.{0}@{1}".format(str_type, mode)] = scales[str_type] * data_yhat["{0}@{1}".format(str_type, mode)]

    df_w = pd.DataFrame(
        np.concatenate([w_true_global, weighted_w, mean_w, single_w], 1),
        columns=["global_true_w", "weighted_w", "mean_w", "single_w"]
    )
    print(df_w.corr())
    print(df_w.std())

    df_yhat_test = pd.DataFrame()
    for k in data_yhat.keys():
        if k.endswith("@test"):
            df_yhat_test[k] = data_yhat[k].reshape([-1])
    print(df_yhat_test.corr())
    print(df_yhat_test.std())

    for mode in ["train", "test"]:
        print("="*30)
        for k in data_yhat.keys():
            if k.endswith(mode) and not k.startswith("true") and not k.startswith("scaled."):
                # _corr = [np.corrcoef(yhat_mat[:,i], y_test[:,i])[0,1] for i in range(n_env)]
                _corr = [noncenter_corrcoef(data_yhat[k][:,i], data_yhat["true@"+mode][:,i]) for i in range(n_env)]
                print("{0}, corr min={1:.4f}, max={2:.4f}, mean={3:.4f}, std={4:.4f}".format(
                    k, np.min(_corr), np.max(_corr), np.mean(_corr), np.std(_corr)))
    import IPython; IPython.embed(); sys.exit(0)
