import stml_mft_china_eq.statarb.gym.evaluation as gym_eval
import torch


class SparseDispatcher(object):
    """Sparse dispatcher for mixture of experts.
    The purpose of this class is to create input minibatches for the
    experts and to combine the results of the experts to form a unified
    output tensor. This class takes advantage of sparsity in the gate
    matrix by including in the `Tensor`s for expert i only the batch
    elements for which `gates[b, i] > 0`.

    There are two functions:
        .dispatch - take an input Tensor and create input Tensors for each expert.
        .combine - take output Tensors from each expert and form a combined output
            Tensor. Outputs from different experts for the same batch element are
            summed together, weighted by the provided "gates".
    The class is initialized with a "gates" Tensor, which specifies which
    batch elements go to which experts, and the weights to use when combining
    the outputs.  Batch element b is sent to expert e iff gates[b, e] != 0.
    The inputs and outputs are all two-dimensional [batch, depth].
    Caller is responsible for collapsing additional dimensions prior to
    calling this class and reshaping the output to the original shape.

    Example usage:
        gates: a float32 `Tensor` with shape `[batch_size, num_experts]`
        inputs: a float32 `Tensor` with shape `[batch_size, input_size]`
        experts: a list of length `num_experts` containing sub-networks.
        dispatcher = SparseDispatcher(num_experts, gates)
        expert_inputs = dispatcher.dispatch(inputs)
        expert_outputs = [experts[i](expert_inputs[i]) for i in range(num_experts)]
        outputs = dispatcher.combine(expert_outputs)
    The preceding code sets the output for a particular example b to:
        output[b] = Sum_i(gates[b, i] * experts[i](inputs[b]))
    """
    def __init__(self, num_experts, gates, device):
        """Create a SparseDispatcher.

        Args:
            num_experts: int
            gates: (batch_size, num_experts) gating weights
            device: str
        """
        self._gates = gates
        self._num_experts = num_experts
        # sort experts
        sorted_experts, index_sorted_experts = torch.nonzero(gates).sort(0)
        # drop indices
        _, self._expert_index = sorted_experts.split(1, dim=1)
        # get according batch index for each expert
        self._batch_index = torch.nonzero(gates)[index_sorted_experts[:, 1],0]
        # calculate num samples that each expert gets
        self._part_sizes = (gates > 0).sum(0).tolist()
        # expand gates to match with self._batch_index
        gates_exp = gates[self._batch_index.flatten()]
        self._nonzero_gates = torch.gather(gates_exp, 1, self._expert_index)
        self.device = device

    def dispatch(self, inp):
        """Create one input Tensor for each expert.
        The `Tensor` for a expert `i` contains the slices of `inp` corresponding
        to the batch elements `b` where `gates[b, i] > 0`.

        Args:
            inp: a `Tensor` of shape "[batch_size, <extra_input_dims>]`
        Returns:
            a list of `num_experts` `Tensor`s with shapes
                `[expert_batch_size_i, <extra_input_dims>]`.
            NOTE: each expert_batch_size_i may be different due to the sparse routing.
        """
        # assigns samples to experts whose gate is nonzero
        # expand according to batch index so we can just split by _part_sizes
        inp_exp = inp[self._batch_index].squeeze(1)
        return torch.split(inp_exp, self._part_sizes, dim=0)


    def combine(self, expert_out, multiply_by_gates=True, do_exp_transform=False):
        """Sum together the expert output, weighted by the gates.
        The slice corresponding to a particular batch element `b` is computed
        as the sum over all experts `i` of the expert output, weighted by the
        corresponding gate values.  If `multiply_by_gates` is set to False, the
        gate values are ignored.

        Args:
            expert_out: a list of `num_experts` `Tensor`s, each with shape
                `[expert_batch_size_i, <extra_output_dims>]`.
            multiply_by_gates: boolean
            do_exp_transform: bool, whether expert_out are going to exp transform
        Returns:
            a `Tensor` with shape `[batch_size, <extra_output_dims>]`.
        """
        stitched = torch.cat(expert_out, 0)
        if do_exp_transform:
            # apply exp to expert outputs, so we are not longer in log space
            stitched = stitched.exp()

        if multiply_by_gates:
            stitched = stitched.mul(self._nonzero_gates)
        zeros = torch.zeros(self._gates.size(0), expert_out[-1].size(1), requires_grad=True).to(self.device)
        # combine samples that have been processed by the same k experts
        combined = zeros.index_add(0, self._batch_index, stitched.float()).to(self.device)

        if do_exp_transform:
            # add eps to all zero values in order to avoid nans when going back to log space
            combined[combined == 0] = np.finfo(float).eps
            return combined.log()
        else:
            return combined


    def expert_to_gates(self):
        """Gate values corresponding to the examples in the per-expert `Tensor`s.

        Returns:
          a list of `num_experts` one-dimensional `Tensor`s with type `tf.float32`
              and shapes `[expert_batch_size_i]`
        """
        # split nonzero gates for each expert
        return torch.split(self._nonzero_gates, self._part_sizes, dim=0)


def _evaluate_net(
    vec_y, vec_yhat,
    list_metrics_regeval=["RelMSE", "R2", "CorrR", "IC1", "SpearmanRho", "CC", "slope", "Q(RET)"]
):
    stats_y = gym_eval.eval_stats(vec_y, is_res_dataframe=True)
    stats_yhat = gym_eval.eval_stats(vec_yhat, is_res_dataframe=True)
    stats_y.index = ["y"]
    stats_yhat.index = ["yhat"]
    # df_stats = pd.concat([stats_y_train_total, stats_yhat_train_total], axis=0)
    df_regeval = gym_eval.eval_regression(vec_y, vec_yhat, is_res_dataframe=True, list_metrics=list_metrics_regeval)
    df_regeval.index = ["yhatAll"]
    idx_pos = (vec_yhat > 0)
    df_regeval_pos = gym_eval.eval_regression(vec_y[idx_pos], vec_yhat[idx_pos], is_res_dataframe=True, list_metrics=list_metrics_regeval)
    df_regeval_pos.index = ["yhatPos"]
    idx_neg = (vec_yhat < 0)
    df_regeval_neg = gym_eval.eval_regression(vec_y[idx_neg], vec_yhat[idx_neg], is_res_dataframe=True, list_metrics=list_metrics_regeval)
    df_regeval_neg.index = ["yhatNeg"]
    return stats_y, stats_yhat, df_regeval, df_regeval_pos, df_regeval_neg


def evaluate_net(m, dataloader_x_y):
    is_training_before = m.training
    m.eval()
    vec_y, vec_yhat = [], []
    with torch.no_grad():
        for xx, yy in dataloader_x_y:
            vec_y.append(yy.reshape([-1]).to("cpu"))
            vec_yhat.append(m(xx.to(m.device)).reshape([-1]).to("cpu"))
    vec_y = torch.cat(vec_y).float()
    vec_yhat = torch.cat(vec_yhat).float()
    stats_y, stats_yhat, regeval, regeval_pos, regeval_neg = _evaluate_net(vec_y, vec_yhat)
    if is_training_before:
        m.train()
    return stats_y, stats_yhat, regeval, regeval_pos, regeval_neg
