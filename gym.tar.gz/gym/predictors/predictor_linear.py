# -*- coding: utf-8 -*-
"""
Linear predictors
"""
import logging
import numpy as np
import cvxpy as cp
from sklearn import linear_model


def get_adjust_positive_scale(yhat, y, EPSILON=1e-20):
    """min_{a>=0} (a * yhat - y)**2"""
    yhat = yhat.reshape([-1])
    y = y.reshape([-1])
    scale_a = np.maximum(np.mean(yhat*y) / (np.mean(yhat**2) + EPSILON), 0.0)
    if not np.isfinite(scale_a):
        scale_a = 0.0
    return scale_a


class ElasticNet(linear_model.ElasticNet):
    """ElasticNet regressor"""
    def __init__(self, **kwargs):
        super(ElasticNet, self).__init__(**kwargs)


class Ridge(linear_model.ElasticNet):
    """Ridge regressor"""
    def __init__(self, **kwargs):
        kwargs.update({
            "l1_ratio": 0,
        })
        super(Ridge, self).__init__(**kwargs)


class Lasso(linear_model.ElasticNet):
    """Lasso regressor"""
    def __init__(self, **kwargs):
        kwargs.update({
            "l1_ratio": 1,
        })
        super(Lasso, self).__init__(**kwargs)


class ZeroPredictor:
    """Always output to zeros"""
    def __init__(self):
        self._n_dim_x = None
        self._n_dim_y = None

    def fit(self, x, y, **kwargs):
        self._n_dim_x = x.shape[1]
        if y.ndim == 1:
            self._n_dim_y = 1
        elif y.ndim == 2:
            self._n_dim_y = y.shape[1]
        else:
            raise ValueError("Not supported")

        self.alpha = 0.0
        self.l1_ratio = 0.0
        self.coef_ = np.zeros(self._n_dim_x)
        return self

    def predict(self, x):
        if x.shape[1] != self._n_dim_x:
            raise ValueError("Dimension inconsistent with record")
        return np.zeros((x.shape[0], self._n_dim_y))


class MMElasticNet(linear_model.LinearRegression):
    """Momentum or mean-reverting preference constrained ElasticNet regressor"""
    def __init__(self, type_mm="mom", alpha=1.0, l1_ratio=0.5, precompute=False, **kwargs):
        """
        Args:
            type_mm: str, indicate the type of preference, "mom" for momentum or "mr" for mean-reversion
            alpha: float, the ridge penalty multiplier
            l1_ratio: float, the ElasticNet mixing parameter, with 0 <= l1_ratio <= 1. For l1_ratio = 0 the penalty is an L2 penalty. For l1_ratio = 1 it is an L1 penalty. For 0 < l1_ratio < 1, the penalty is a combination of L1 and L2.
            precompute: bool or array-like of shape (n_dim_x, n_dim_x), default=False. If not False, the input is the precomputed Gram matrix np.dot(X.T, X).
            kwargs: other keyword arguments to feed in base, i.e., sklearn.linear_model.LinearRegression.
        """
        if type_mm not in ["mom", "mr"]:
            raise ValueError("type_mm should be either 'mom' for momentum or 'mr' for mean-reversion")
        if kwargs.get("fit_intercept", False):
            raise NotImplementedError("fit_intercept is fixed as False here")
        kwargs["fit_intercept"] = False
        super(MMElasticNet, self).__init__(**kwargs)
        self.intercept_ = 0.0
        self.type_mm = type_mm
        self.alpha = alpha
        self.l1_ratio = l1_ratio
        self.precompute = precompute

    def fit(self, X, y, Z, sample_weight=None, verbose=False):
        """
        Args:
            X: (n_samples, n_dim_x), training features.
            y: (n_samples,) or (n_samples, n_dim_y), training targets.
            Z: (n_samples,) or (n_samples, n_dim_z), training lagging returns.
                if n_dim_z>1, all dimensions of Z are constrained to be of the same preference.
            sample_weight: None or (n_samples,) training weights
            verbose: bool
        """
        if not X.shape[0] == y.shape[0] == Z.shape[0]:
            raise ValueError("Shapes of X={0}, y={1}, Z={2}, unmatched!".format(
                X.shape, y.shape, Z.shape
            ))
        X, y, _, _, _ = self._preprocess_data(
            X, y, self.fit_intercept, self.normalize, self.copy_X)
        if y.ndim == 1:
            y = y[:, np.newaxis]
        if Z.ndim == 1:
            Z = Z[:, np.newaxis]
        if sample_weight is not None:
            if X.shape[0] != len(sample_weight):
                raise ValueError("Shapes of X={0}, y={1}, Z={2}, but sample_weight={3}, unmatched!".format(
                    X.shape, y.shape, Z.shape, sample_weight.shape
                ))
            sample_weight = float(X.shape[0]) * sample_weight / np.sum(sample_weight)

        self.n_dim_x = X.shape[1]
        self.n_dim_y = y.shape[1]

        if isinstance(self.precompute, bool) and not self.precompute:
            if sample_weight is None:
                E_XX = np.dot(X.T, X) / X.shape[0]
            else:
                E_XX = np.dot(X.T * np.reshape(sample_weight, [1,-1]), X) / X.shape[0]
        else:
            E_XX = self.precompute / X.shape[0]
        if sample_weight is None:
            E_Xy = np.dot(X.T, y) / X.shape[0]
        else:
            E_Xy = np.dot(X.T * np.reshape(sample_weight, [1,-1]), y) / X.shape[0]
        E_XZ = np.dot(X.T, Z) / X.shape[0]

        self.coef_ = np.zeros((self.n_dim_y, self.n_dim_x))
        # dims of y are independent from each other
        for i_y in range(self.n_dim_y):
            self.coef_[i_y, :] = self.fit_1d_y(
                X, y[:, i_y], Z,
                E_XX=E_XX, E_Xy=E_Xy[:, i_y], E_XZ=E_XZ,
                verbose=verbose)

        return self

    def fit_1d_y(self, X, y, Z, E_XX=None, E_Xy=None, E_XZ=None, verbose=False):
        """
        Args:
            X: (n_samples, n_dim_x), training features.
            y: (n_samples,), 1d training targets.
            Z: (n_samples, n_dim_z), training lagging returns.
            E_XX: None or (n_dim_x, n_dim_x), E_XZ = np.dot(X.T, X) / X.shape[0]
            E_Xy: None or (n_dim_x, ), E_Xy = np.dot(X.T, y) / X.shape[0]
            E_XZ: None or (n_dim_x, n_dim_z), E_XZ = np.dot(X.T, Z) / X.shape[0]
            verbose: bool
        Returns:
            res_coef_w: (n_dim_x,) coefficient vector
        """
        assert y.ndim == 1
        if E_XX is None:
            E_XX = np.dot(X.T, X) / X.shape[0]
        if E_Xy is None:
            E_Xy = np.dot(X.T, y) / X.shape[0]
        if E_XZ is None:
            E_XZ = np.dot(X.T, Z) / X.shape[0]

        if verbose:
            logging.debug("Start of cvxpy optimization")
        coef_w = cp.Variable(self.n_dim_x)
        alpha = cp.Parameter(nonneg=True)
        alpha.value = self.alpha
        l1_ratio = cp.Parameter(nonneg=True)
        l1_ratio.value = self.l1_ratio
        if self.type_mm == "mom":
            constraints = [coef_w @ E_XZ >= 0]
        elif self.type_mm == "mr":
            constraints = [coef_w @ E_XZ <= 0]

        bool_use_qp = True
        if bool_use_qp:
            objective = self._objective_fn_1d_qp(E_XX, E_Xy, coef_w, alpha, l1_ratio)
        else:
            objective = self._objective_fn_1d_general(X, y, coef_w, alpha, l1_ratio)

        prob = cp.Problem(cp.Minimize(objective), constraints)
        if verbose:
            logging.debug("\tcvxpy problem formulation done")

        try:
            prob.solve(verbose=verbose, solver=cp.ECOS)
        except cp.error.SolverError:
            prob.solve(verbose=verbose, solver=cp.SCS)
        if verbose:
            logging.debug("\tcvxpy problem solving done")

        try:
            res_coef_w = coef_w.value.copy()      # shape = (n_features,)
        except:
            logging.warn("some robustness problems of cvxpy, have to set coefficients as zeros")
            res_coef_w = np.zeros(self.n_dim_x)

        if verbose:
            logging.debug("The constraints are {}".format(np.dot(res_coef_w, E_XZ).squeeze()))
        return res_coef_w

    def _objective_fn_1d_general(self, X, y, coef_w, alpha, l1_ratio):
        """Objective function of Ridge regression used in cvxpy (NOT explicitly in QP form).
        To keep consistency, here we use the same formulation as sklearn.linear_model.ElasticNet and thus Ridge
        """
        _loss_fn = 0.5 * cp.pnorm(X @ coef_w - y, p=2)**2 / X.shape[0]
        _regularizer_l2 = 0.5 * alpha * (1 - l1_ratio) * cp.pnorm(coef_w, p=2)**2
        _regularizer_l1 = alpha * l1_ratio * cp.norm1(coef_w)
        return _loss_fn + _regularizer_l2 + _regularizer_l1

    def _objective_fn_1d_qp(self, E_XX, E_Xy, coef_w, alpha, l1_ratio):
        """Objective function of Ridge regression used in cvxpy (explicitly in QP form).
        To keep consistency, here we use the same formulation as sklearn.linear_model.ElasticNet and thus Ridge
        """
        mat_P = E_XX + alpha.value * (1 - l1_ratio.value) * np.eye(E_XX.shape[1])
        _order2 = 0.5 * cp.quad_form(coef_w, mat_P)
        _order1 = - E_Xy.T @ coef_w
        _regularizer_l1 = alpha.value * l1_ratio.value * cp.norm1(coef_w)
        return _order2 + _order1 + _regularizer_l1


class MMRidge(MMElasticNet):
    """Momentum or mean-reverting preference constrained Ridge regressor"""
    def __init__(self, **kwargs):
        kwargs.update({
            "l1_ratio": 0,
        })
        super(MMRidge, self).__init__(**kwargs)


class MMLasso(MMElasticNet):
    """Momentum or mean-reverting preference constrained Lasso regressor"""
    def __init__(self, **kwargs):
        kwargs.update({
            "l1_ratio": 1,
        })
        super(MMLasso, self).__init__(**kwargs)


class RobustMMElasticNet(linear_model.LinearRegression):
    """Robust over momentum and mean-reverting ElasticNet regressor."""
    def __init__(self, alpha=1.0, l1_ratio=0.5, lamb=100.0, precompute=False, **kwargs):
        """
        Args:
            alpha: float, the ridge penalty multiplier
            l1_ratio: float, the ElasticNet mixing parameter, with 0 <= l1_ratio <= 1. For l1_ratio = 0 the penalty is an L2 penalty. For l1_ratio = 1 it is an L1 penalty. For 0 < l1_ratio < 1, the penalty is a combination of L1 and L2.
            lamb: float, the regularization strength of robustness
            precompute: bool or array-like of shape (n_dim_x, n_dim_x), default=False. If not False, the input is the precomputed Gram matrix np.dot(X.T, X).
            kwargs: other keyword arguments to feed in base, i.e., sklearn.linear_model.LinearRegression.
        """
        if kwargs.get("fit_intercept", False):
            raise NotImplementedError("fit_intercept is fixed as False here")
        kwargs["fit_intercept"] = False
        super(RobustMMElasticNet, self).__init__(**kwargs)
        self.intercept_ = 0.0
        self.alpha = alpha
        self.l1_ratio = l1_ratio
        self.lamb = lamb
        self.precompute = precompute

    def fit(self, X, y, Z, sample_weight=None, verbose=False):
        """
        Args:
            X: (n_samples, n_dim_x), training features.
            y: (n_samples,) or (n_samples, n_dim_y), training targets.
            Z: (n_samples,) or (n_samples, n_dim_z), training lagging returns.
                if n_dim_z>1, all dimensions of Z are used to multiplied with y to get conditional variables.
            sample_weight: None or (n_samples,) training weights
            verbose: bool
        """
        if not X.shape[0] == y.shape[0] == Z.shape[0]:
            raise ValueError("Shapes of X={0}, y={1}, Z={2}, unmatched!".format(
                X.shape, y.shape, Z.shape
            ))
        X, y, _, _, _ = self._preprocess_data(
            X, y, self.fit_intercept, self.normalize, self.copy_X)
        if y.ndim == 1:
            y = y[:, np.newaxis]
        if Z.ndim == 1:
            Z = Z[:, np.newaxis]
        if sample_weight is not None:
            if X.shape[0] != len(sample_weight):
                raise ValueError("Shapes of X={0}, y={1}, Z={2}, but sample_weight={3}, unmatched!".format(
                    X.shape, y.shape, Z.shape, sample_weight.shape
                ))
            sample_weight = float(X.shape[0]) * sample_weight / np.sum(sample_weight)

        self.n_dim_x = X.shape[1]
        self.n_dim_y = y.shape[1]

        if isinstance(self.precompute, bool) and not self.precompute:
            if sample_weight is None:
                E_XX = np.dot(X.T, X) / X.shape[0]
            else:
                E_XX = np.dot(X.T * np.reshape(sample_weight, [-1,1]), X) / X.shape[0]
        else:
            E_XX = self.precompute / X.shape[0]

        self.coef_ = np.zeros((self.n_dim_y, self.n_dim_x))
        # dims of y are independent from each other
        for i_y in range(self.n_dim_y):
            self.coef_[i_y, :] = self.fit_1d_y(
                X, y[:, i_y], Z,
                lamb=self.lamb,
                sample_weight=sample_weight, verbose=verbose)

        return self

    def fit_1d_y(self, X, y, Z, lamb=100.0, sample_weight=None, do_positive_rescale=True, verbose=False):
        """
        Args:
            X: (n_samples, n_dim_x), training features.
            y: (n_samples,), 1d training targets.
            Z: (n_samples, n_dim_z), training lagging returns.
            lamb: float, the weight to penalize the consistency across different conditions.
            sample_weight: None or (n_samples,) training weights
            do_positive_rescale: bool, whether rescale the coeffcients. Default: True
            verbose: bool
        Returns:
            res_coef_w: (n_dim_x,) coefficient vector
        """
        #TODO: add sample_weight support in future
        assert y.ndim == 1

        # split conditions
        Zy = Z * np.expand_dims(y, 1)
        list_E_Xy = []
        list_E_Xy3 = []
        list_E_XX = []
        list_E_XXy2 = []
        list_E_X4 = []
        list_E_X3y = []
        for i_z in range(Z.shape[1]):
            for idx in [Zy[:,i_z] >= 0, Zy[:,i_z] <= 0]:
                n_idx = np.sum(idx)
                if n_idx > 0:
                    list_E_Xy.append(np.expand_dims(np.dot(X[idx].T, y[idx]) / n_idx, 0))
                    list_E_Xy3.append(np.expand_dims(np.dot(X[idx].T, y[idx]**3) / n_idx, 0))
                    list_E_XX.append(np.expand_dims(np.dot(X[idx].T, X[idx]) / n_idx, 0))
                    list_E_XXy2.append(np.expand_dims(np.dot(X[idx].T, X[idx] * np.expand_dims(y[idx]**2, 1)) / n_idx, 0))
                    list_E_X4.append(np.expand_dims(np.dot((X[idx] * np.mean(X[idx]**2, 1, keepdims=True)).T, X[idx])  / n_idx, 0))
                    list_E_X3y.append(np.expand_dims(np.dot((X[idx] * np.mean(X[idx]**2, 1, keepdims=True)).T, y[idx])  / n_idx, 0))

        mean_E_Xy = np.mean(np.concatenate(list_E_Xy, 0), 0, keepdims=False)
        mean_E_Xy3 = np.mean(np.concatenate(list_E_Xy3, 0), 0, keepdims=False)
        mean_E_XX = np.mean(np.concatenate(list_E_XX, 0), 0, keepdims=False)
        mean_E_XXy2 = np.mean(np.concatenate(list_E_XXy2, 0), 0, keepdims=False)
        mean_E_X4 = np.mean(np.concatenate(list_E_X4, 0), 0, keepdims=False)
        mean_E_X3y = np.mean(np.concatenate(list_E_X3y, 0), 0, keepdims=False)

        if verbose:
            logging.debug("Start of cvxpy optimization")
        coef_w = cp.Variable(self.n_dim_x)
        alpha = cp.Parameter(nonneg=True)
        alpha.value = self.alpha
        l1_ratio = cp.Parameter(nonneg=True)
        l1_ratio.value = self.l1_ratio

        objective = self._objective_fn_1d_qp(mean_E_XX + lamb * mean_E_X4, mean_E_Xy + lamb * mean_E_X3y, coef_w, alpha, l1_ratio)
        prob = cp.Problem(cp.Minimize(objective))
        if verbose:
            logging.debug("\tcvxpy problem formulation done")

        try:
            prob.solve(verbose=verbose, solver=cp.ECOS)
        except cp.error.SolverError:
            prob.solve(verbose=verbose, solver=cp.SCS)
        except Exception as e:
            objective = self._objective_fn_1d_qp(mean_E_XX, mean_E_Xy, coef_w, alpha, l1_ratio)
            prob = cp.Problem(cp.Minimize(objective))
            prob.solve(verbose=verbose, solver=cp.ECOS)

        if verbose:
            logging.debug("\tcvxpy problem solving done")

        try:
            res_coef_w = coef_w.value.copy()      # shape = (n_features,)
            if do_positive_rescale:
                positive_scale = get_adjust_positive_scale(np.dot(X, res_coef_w), y)
                res_coef_w *= positive_scale
        except:
            logging.warn("some robustness problems of cvxpy, have to set coefficients as zeros")
            res_coef_w = np.zeros(self.n_dim_x)

        return res_coef_w

    def _objective_fn_1d_qp(self, E_XX, E_Xy, coef_w, alpha, l1_ratio):
        """Objective function of Ridge regression used in cvxpy (explicitly in QP form).
        To keep consistency, here we use the same formulation as sklearn.linear_model.ElasticNet and thus Ridge
        """
        mat_P = E_XX + alpha.value * (1 - l1_ratio.value) * np.eye(E_XX.shape[1])
        uu, dd, _ = np.linalg.svd(mat_P)
        uu, dd = np.real(uu), np.real(dd)
        dd = np.maximum(dd, 0.0)
        half_mat_P = np.dot(uu, np.diag(np.sqrt(dd)))
        _order2 = 0.5 * cp.sum_squares(coef_w @ half_mat_P)
        _order1 = - E_Xy.T @ coef_w
        _regularizer_l1 = alpha.value * l1_ratio.value * cp.norm1(coef_w)
        return _order2 + _order1 + _regularizer_l1


class RobustMMRidge(RobustMMElasticNet):
    """Robust oer momentum or mean-reverting Ridge regressor"""
    def __init__(self, **kwargs):
        kwargs.update({
            "l1_ratio": 0,
        })
        super(RobustMMRidge, self).__init__(**kwargs)


class RobustMMLasso(RobustMMElasticNet):
    """Robust momentum or mean-reverting Lasso regressor"""
    def __init__(self, **kwargs):
        kwargs.update({
            "l1_ratio": 1,
        })
        super(RobustMMLasso, self).__init__(**kwargs)


