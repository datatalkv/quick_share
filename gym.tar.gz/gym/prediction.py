# -*- coding: utf-8 -*-
"""
Prediction modules. Key functional steps (according to experimental settings):
* load data
* load normalizers and precitors
* make predictions
* postprocessing and store the resulted vdf files
"""
import time
from collections import Sequence, namedtuple
import os
import numpy as np
import pandas as pd
import logging

from stml_mft_china_eq.pyutils import iom
from stml_mft_china_eq.pyutils import datetime_utils as dtu
from stml_mft_china_eq.pyutils.misc_utils import maybe_function_call

from stml_mft_china_eq.configs import static_data, const
from stml_mft_china_eq.statarb import utils, path_utils
from stml_mft_china_eq.statarb.gym.data import Dataset
from stml_mft_china_eq.statarb.gym.predictors import ZeroPredictor, TODMOEPredictor
from stml_mft_china_eq.statarb.gym import utils as gymutils
from stml_mft_china_eq.statarb.data_loader.factory import default_factory


class Prediction:
    # state maintained per date for the prediction
    FittingData = namedtuple('State', ['normalizer', 'predictor', 'fitting_meta', 'dataset', 'symbol_meta', 'tsv_risk'])

    def __init__(
        self,
        raw_data_base_dir,
        prediction_base_dir,
        fitting_dir,
        fitting_code,
        signal_name='yhat',
        signal_abs_bound=1.0,
        risk_model=None,
        str_risk_multiply_to_signal="trisk",
        data_loader_factory=None,
        dtype='float64'
    ):
        """[summary]

        Args:
            prediction_base_dir: str, the base dir to output the prediction results
            fitting_dir: str, the dir which stores the fitting files
            fitting_code: str, the fitting code
            signal_name: str, the name of signal that will be stored in the panels
            signal_abs_bound: float, the maximum of absolute values before multiply with risk
            risk_model: callable or risk model instance, which to provide the risk to be multiplied
            str_risk_multiply_to_signal: None or str, which risk to be multiplied to the signals, see gymutils.type_date2df_risk().
            dtype: str, the output dtype
        """
        data_loader_factory = data_loader_factory if data_loader_factory else default_factory()
        self._raw_data_base_dir = raw_data_base_dir
        self._prediction_base_dir = prediction_base_dir
        self._static_data = static_data.StaticData(path_utils.get_static_data_dir(raw_data_base_dir))
        self._fitting_code = fitting_code
        self._fitting_dir = fitting_dir
        self._signal_name = signal_name
        self._signal_abs_bound = signal_abs_bound
        self._str_risk_multiply_to_signal = str_risk_multiply_to_signal
        self._risk_model = maybe_function_call(risk_model)
        if self._str_risk_multiply_to_signal and risk_model is None:
            raise ValueError("risk model must be provided with valid str_risk_multiply_to_signal")

        self._prediction_loader = data_loader_factory(self.dir_data)
        self._data_loader_factory = data_loader_factory
        self._fitting_data = {} # dataset by date instance
        self._dtype = dtype

    @property
    def fitting_dir(self):
        return self._fitting_dir

    @property
    def dir_data(self):
        # with different params, we should put into a different default directory
        return os.path.join(self._prediction_base_dir,  "res_yhat_panels", self._fitting_code)

    @property
    def raw_data_base_dir(self):
        return self._raw_data_base_dir

    @property
    def prediction_aux_config(self):
        """Auxiliary info to be saved in the DB
        """
        return {
            'signal_abs_bound': self._signal_abs_bound,
            'str_risk_multiply_to_signal': self._str_risk_multiply_to_signal
        }

    def load_fitting_data(self, date, symbols=None, base_dir_mapping=None):
        """Get the fitting information for a given date

        Args:
            date: YYYYMMDD, date
            symbols: list, symbols to do the predictions, subset of the trade symbols. Default to be the trade symbols
            base_dir_mapping: tuple, optional mapping of path to load the x_list_dirfile_features

        Returns:
            [type]: [description]
        """
        date = dtu.to_date_int(date)
        try:
            fitting_data = self._fitting_data[date]
            if symbols:
                assert fitting_data.dataset.symbols == symbols
            return fitting_data
        except KeyError:
            try:
                fname_normalizer, fname_predictor, fname_meta = gymutils.fetch_most_recent_files_for_date(
                    self.fitting_dir, date, ["normalizer", "predictor", "meta"],
                )
                normalizer = iom.read_pickle(fname_normalizer)
                predictor = iom.read_pickle(fname_predictor)
                fitting_meta = iom.read_json(fname_meta, object_pairs_hook=utils.deunicodify_hook)
            except:
                fname_predictor, fname_meta = gymutils.fetch_most_recent_files_for_date(
                    self.fitting_dir, date, ["predictor", "meta"],
                )
                fname_normalizer = None
                normalizer = None
                predictor = iom.read_pickle(fname_predictor)
                fitting_meta = iom.read_json(fname_meta, object_pairs_hook=utils.deunicodify_hook)

            if base_dir_mapping:
                fitting_meta = utils.recursive_replace_base_dir(fitting_meta, *base_dir_mapping)
            logging.debug("date={0}, fname_normalizer={1}, fname_predictor={2}, fnanme_meta={3}".format(
                date, fname_normalizer, fname_predictor, fname_meta
            ))

            assert fitting_meta['raw_data_base_dir'].rstrip("/") == self._raw_data_base_dir.rstrip("/"), \
                "Inconsistent raw_data_base_dir, fitting raw_data_base_dir={}, prediction raw_data_base_dir={}".format()

            symbols = symbols if symbols else fitting_meta['symbols']
            assert set(symbols) <= set(fitting_meta['symbols']), "prediction symbols must be a subset of fitting symbols"

            dataset = Dataset(
                symbols=symbols,
                x_list_dirfile_features=fitting_meta['x_list_dirfile_features'],
                y_list_dirfile_features=None,
                w_list_dirfile_features=None,
                mask_list_dirfile_features=None,
                name_prefix=self._fitting_code,
                data_loader_factory=self._data_loader_factory,
                col_name_prefix=fitting_meta['raw_data_base_dir']
            )

            symbol_meta = self._static_data.get_symbols_meta_by_sector(sector="ALL", symbols=symbols)

            if self._str_risk_multiply_to_signal is None or self._str_risk_multiply_to_signal.lower()=="none":
                tsv_risk = None
            else:
                df_risk = gymutils.type_date2df_risk(self._risk_model, self._str_risk_multiply_to_signal, date)
                tsv_risk = np.reshape(df_risk.loc[dataset.symbols].values, [1, -1, 1])

            self._fitting_data[date] = Prediction.FittingData(
                normalizer=normalizer,
                predictor=predictor,
                fitting_meta=fitting_meta,
                dataset=dataset,
                symbol_meta=symbol_meta,
                tsv_risk=tsv_risk)
            return self._fitting_data[date]

    def load_date(self, cur_date, symbols):
        return self.load_fitting_data(cur_date, symbols)

    @gymutils.timing
    def build_for_intervals(
        self,
        date,
        interval,
        num_intervals,
        symbols=None,
        overwrite=False
    ):
        """Build the features of num_intervals up to "interval" on "date"
        """
        assert interval + 1 >= num_intervals, "{} intervals up to interval {} crosses date".format(num_intervals, interval)
        if not overwrite and self._prediction_loader.is_dataframe_exist(date, interval, num_intervals):
            return

        date = dtu.to_date_int(date)
        normalizer, predictor, fitting_meta, dataset, symbol_meta, tsv_risk = self.load_fitting_data(date, symbols)

        dataset.load_by_interval(
            date=date, interval=interval, num_intervals=num_intervals,
            down_sample_ratio=None, verbose=False
        )
        dataset.logging_shapes()

        x_tsv, _, _, _, _ = dataset.get_tsvdata_all()

        # normalizer transform
        if normalizer is not None:
            logging.debug("Transform x features by normalizer")
            if fitting_meta['normalizer_fitby'] == "universe":
                x_nv_norm = normalizer.transform(gymutils.tsv2nv(x_tsv), dataset.cols_x)
                x_tsv_norm = gymutils.nv2tsv(x_nv_norm, len(dataset.symbols))
            elif fitting_meta['normalizer_fitby'] == "sector":
                raise NotImplementedError()
                symbol2sector = dict(symbol_meta[["symbol", "sector"]].values)
                x_tsv_norm = np.concatenate([
                    np.expand_dims(normalizer[symbol2sector[symbol]].transform(x_tsv[:,i_symbol,:], dataset.cols_x), 1)
                    for i_symbol, symbol in enumerate(dataset.symbols)
                ], 1)
            elif fitting_meta['normalizer_fitby'] == "symbol":
                raise NotImplementedError()
                x_tsv_norm = np.concatenate([
                    np.expand_dims(normalizer[symbol].transform(x_tsv[:,i_symbol,:], dataset.cols_x), 1)
                    for i_symbol, symbol in enumerate(dataset.symbols)
                ], 1)
            else:
                raise NotImplementedError()
        else:
            x_tsv_norm = x_tsv

        # predict and form the panel
        # TODO: pass intervals to TODMOE objects
        logging.debug("Forecast yhat signals")
        if fitting_meta['predictor_fitby'] == "universe":
            yhat_nv = predictor.predict(gymutils.tsv2nv(x_tsv_norm)).reshape([-1, 1])
            idx_out = np.abs(yhat_nv)>self._signal_abs_bound
            yhat_nv[idx_out] = self._signal_abs_bound * np.sign(yhat_nv[idx_out])
            yhat_tsv = gymutils.nv2tsv(yhat_nv, len(dataset.symbols))
        elif fitting_meta['predictor_fitby'] == "sector":
            raise NotImplementedError()
            symbol2sector = dict(symbol_meta[["symbol", "sector"]].values)
            yhat_tsv = []
            for i_symbol, symbol in enumerate(dataset.symbols):
                x_nv_norm = gymutils.tsv2nv(x_tsv_norm[:,[i_symbol],:])
                _this_predictor = predictor.get(
                    symbol2sector[symbol], ZeroPredictor().fit(np.zeros((10, x_nv_norm.shape[1])), np.zeros((10, 1))))
                yhat_nv = _this_predictor.predict(x_nv_norm).reshape([-1, 1, 1])
                yhat_tsv.append(yhat_nv)
            yhat_tsv = np.concatenate(yhat_tsv, 1)
            idx_out = np.abs(yhat_tsv)>self._signal_abs_bound
            yhat_tsv[idx_out] = self._signal_abs_bound * np.sign(yhat_tsv[idx_out])
        elif fitting_meta['predictor_fitby'] == "symbol":
            raise NotImplementedError()
            yhat_tsv = []
            for i_symbol, symbol in enumerate(dataset.symbols):
                x_nv_norm = gymutils.tsv2nv(x_tsv_norm[:,[i_symbol],:])
                _this_predictor = predictor.get(
                    symbol, ZeroPredictor().fit(np.zeros((10, x_nv_norm.shape[1])), np.zeros((10, 1))))
                yhat_nv = _this_predictor.predict(x_nv_norm).reshape([-1, 1, 1])
                yhat_tsv.append(yhat_nv)
            yhat_tsv = np.concatenate(yhat_tsv, 1)
            idx_out = np.abs(yhat_tsv)>self._signal_abs_bound
            yhat_tsv[idx_out] = self._signal_abs_bound * np.sign(yhat_tsv[idx_out])
        else:
            raise NotImplementedError()

        if tsv_risk is not None:
            logging.debug("Multiply yhat signals by risk {}, to project back to unnormalized return space".format(
                self._str_risk_multiply_to_signal))
            yhat_tsv = yhat_tsv * tsv_risk

        yhat_tsv = yhat_tsv.astype(self._dtype)
        df_yhat = gymutils.tsv2df(yhat_tsv, dataset.timestamps, dataset.symbols, [self._signal_name])

        self._prediction_loader.save_dataframe(data=df_yhat)
        logging.debug("Signal panel saved for {} intervals up to {}/{}".format(num_intervals, date, interval))


    def build_date_range(self, start_date, end_date, symbols=None, overwrite=False):
        for date in dtu.date_range_china_eq(start_date, end_date):
            self.build_for_intervals(
                date=date,
                interval=const.N_INTERVALS_DATA_PER_DAY- 1,
                num_intervals=const.N_INTERVALS_DATA_PER_DAY,
                symbols=symbols,
                overwrite=overwrite
            )

def make_predictions(
    raw_data_base_dir,
    prediction_base_dir,
    fittings,
    risk_model,
    signal_abs_bound=1.0,
    str_risk_multiply_to_signal='trisk',
    signal_name='yhat'
):
    """make a list of predictors

    Args:
        fittings, list or callable returning a list, list of fittings details
        risk_model: None or callable or risk model instance, which to provide the risk to be multiplied
        signal_abs_bound: float, the maximum of absolute values before multiply with risk
        str_risk_multiply_to_signal: None or str, which risk to be multiplied to the signals, see gymutils.type_date2df_risk().
        signal_name: str, the name of signal that will be stored in the panels
    """
    fittings = maybe_function_call(fittings)

    def _loop():
        if isinstance(fittings, Sequence) and not isinstance(fittings, basestring):
            for f in fittings:
                yield f
        elif isinstance(fittings, pd.DataFrame):
            for _, row in fittings.iterrows():
                yield row
        else:
            raise ValueError("unknown type of fittings {}".format(fittings))

    predictors = []
    for fitting in _loop():
        fitting_dir = fitting['fitting_dir']
        fitting_code = fitting['fitting_code']
        predictors.append(
            Prediction(
                raw_data_base_dir=raw_data_base_dir,
                prediction_base_dir=prediction_base_dir,
                fitting_dir=fitting_dir,
                fitting_code=fitting_code,
                signal_name=signal_name,
                signal_abs_bound=signal_abs_bound,
                risk_model=risk_model,
                str_risk_multiply_to_signal=str_risk_multiply_to_signal
            )
        )
    return predictors

def make_prediction(
    raw_data_base_dir,
    prediction_base_dir,
    fitting,
    risk_model,
    signal_abs_bound=1.0,
    str_risk_multiply_to_signal='trisk',
    signal_name='yhat'
):
    def _get(fitting):
        if isinstance(fitting, Sequence) and not isinstance(fitting, basestring):
            assert len(fitting) == 1
            return fitting[0]
        elif isinstance(fitting, pd.DataFrame):
            assert len(fitting) == 1
            return fitting.iloc[0]
        return fitting

    fitting = _get(maybe_function_call(fitting))
    return Prediction(
        raw_data_base_dir=raw_data_base_dir,
        prediction_base_dir=prediction_base_dir,
        fitting_dir=fitting['fitting_dir'],
        fitting_code=fitting['fitting_code'],
        signal_name=signal_name,
        signal_abs_bound=signal_abs_bound,
        risk_model=risk_model,
        str_risk_multiply_to_signal=str_risk_multiply_to_signal
    )
