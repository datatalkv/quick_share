# -*- coding: utf-8 -*-
"""
Fitting procedure. Key functional steps (according to experimental settings):
* load data
* fit normalizers
* fit predictors, select hyper-parameters with time series rolling validation
* store normalizers and predictors
"""
import gc
import os
import numpy as np
import pandas as pd
import logging
import hashlib
from collections import OrderedDict, Sequence

from stml_mft_china_eq.pyutils import iom
from stml_mft_china_eq.pyutils.misc_utils import function_call

from stml_mft_china_eq.configs import static_data
from stml_mft_china_eq.statarb import utils, path_utils
from stml_mft_china_eq.statarb.gym.data import Dataset, make_list_dirfile_features
from stml_mft_china_eq.statarb.gym import evaluation as gym_eval
from stml_mft_china_eq.statarb.gym.normalizers import ZNormalizer, QNormalizer, ZeroNormalizer
from stml_mft_china_eq.statarb.gym import predictors
from stml_mft_china_eq.statarb.gym import utils as gymutils


THRES_NONZERO_SIZE = 10

class Fitting:
    def __init__(
        self,
        raw_data_base_dir: str,
        ######### data ##################
        x_list_dirfile_features,
        y_list_dirfile_features,
        z_list_dirfile_features=None,
        w_list_dirfile_features=None,
        mask_list_dirfile_features=None,
        symbols=None,
        down_sample_ratio=0.2,
        down_sample_seed=0,
        ######### roll ##################
        rolling_start_date=20150101,
        rolling_window_n_month=24,
        rolling_update_per_n_month=12,
        ######### normalization #########
        normalizer_model_code='znorm',
        normalizer_fitby='universe',
        normalizer_kwargs=None,
        ######### fitting ###############
        predictor_model_code='ridge',
        predictor_fitby='universe',
        predictor_kwargs=None,
        predictor_skipnfold_outof_kfold=(5, 10),  # # skip the beginning 5 timeseries validation out of 10 folds (i.e., skip too few training samples at the beginnnig, and use the latter trials)
        predictor_param_grid=None,
        predictor_validation_score=None,
        ######### labels ################
        fitting_code=None,
        ######### output ################
        fitting_base_dir=None,
        **kwargs
    ):
        """
        Args:
            raw_data_base_dir, str, the base dir for statarb
            x_list_dirfile_features, list or callable or config file to get list of dirfile_features for X
            y_list_dirfile_features, list or callable or config file to get list of dirfile_features for Y
            z_list_dirfile_features, list or callable or config file to get list of dirfile_features for Z
            w_list_dirfile_features, list or callable or config file to get list of dirfile_features for W
            mask_list_dirfile_features, list or callable or config file to get list of dirfile_features for mask
            symbols, list or callable to get trade symbols
            down_sample_ratio, float, down sample ratio for the panel data
            down_sample_seed, float, seed for the down sampling
            rolling_start_date, YYYYMMDD
            rolling_window_n_month, int, rolling window size
            rolling_update_per_n_month, int, rolling frequency
            normalizer: str, normalizer code, e.g. znorm, qnorm
            normalizer_fit_by: str, normalizer fit by, e.g. symbol, universe
            predictor: str predictor code
            predictor_fit_by: str, predictor fit by, e.g. symbol, universe
            predictor_validation_score
            fitting_code: optional ID assigned to fitting.
            fitting_base_dir: the base dir for outputting the fitting results, default to be raw_data_base_dir
        """
        self._meta = {}

        #################################### data ####################################
        self.x_list_dirfile_features = self._get_dirfile_features(
            x_list_dirfile_features, 'x_list_dirfile_features'
        )
        self.y_list_dirfile_features = self._get_dirfile_features(
            y_list_dirfile_features, 'y_list_dirfile_features'
        )
        self.z_list_dirfile_features = self._get_dirfile_features(
            z_list_dirfile_features, 'z_list_dirfile_features'
        )
        self.w_list_dirfile_features = self._get_dirfile_features(
            w_list_dirfile_features, 'w_list_dirfile_features'
        )
        self.mask_list_dirfile_features = self._get_dirfile_features(
            mask_list_dirfile_features, 'mask_list_dirfile_features'
        )
        self.static_data = static_data.StaticData(path_utils.get_static_data_dir(raw_data_base_dir))

        self.symbols = symbols
        if not self.symbols:
            # get trade symbols by default
            self.symbols = self.static_data.trade_symbols
        self.raw_data_base_dir = raw_data_base_dir
        self.down_sample_ratio = down_sample_ratio
        self.down_sample_seed = down_sample_seed
        #################################### roll ####################################
        self.rolling_start_date = rolling_start_date
        self.rolling_window_n_month = rolling_window_n_month
        self.rolling_update_per_n_month = rolling_update_per_n_month
        #################################### normalization ###########################
        self.normalizer_model_code = normalizer_model_code
        self.normalizer_fitby = normalizer_fitby
        self.normalizer_kwargs = normalizer_kwargs
        self.normalizer_kwargs = {} if normalizer_kwargs is None else normalizer_kwargs
        #################################### fitting #################################
        self.predictor_model_code = predictor_model_code
        self.predictor_fitby = predictor_fitby
        self.predictor_kwargs = predictor_kwargs
        if self.predictor_kwargs is None:
            self.predictor_kwargs = predictors.get_default_kwargs(predictor_model_code)
        self.predictor_skipnfold_outof_kfold = predictor_skipnfold_outof_kfold
        self.predictor_param_grid = predictor_param_grid
        if self.predictor_param_grid is None:
            self.predictor_param_grid = predictors.get_default_param_grid(predictor_model_code)
        self.predictor_validation_score = predictor_validation_score
        #################################### labels ####################################
        self._fitting_code = fitting_code
        self._fitting_base_dir = fitting_base_dir
        if not self._fitting_base_dir:
            self._fitting_base_dir = raw_data_base_dir

    @property
    def weekdays_only(self):
        return self.static_data.weekdays_only

    @property
    def meta(self):
        """Meta info about the fitting, to be persisted in the file system along with the fitting results
        """
        d = {
            'raw_data_base_dir': self.raw_data_base_dir,
            'x_list_dirfile_features': self.x_list_dirfile_features,
            'y_list_dirfile_features': self.y_list_dirfile_features,
            'z_list_dirfile_features': self.z_list_dirfile_features,
            'w_list_dirfile_features': self.w_list_dirfile_features,
            'mask_list_dirfile_features': self.mask_list_dirfile_features,
            'symbols': self.symbols,
            'down_sample_ratio': self.down_sample_ratio,
            'down_sample_seed': self.down_sample_seed,
            'rolling_start_date': self.rolling_start_date,
            'rolling_window_n_month': self.rolling_window_n_month,
            'rolling_update_per_n_month': self.rolling_update_per_n_month,
            'normalizer_model_code': self.normalizer_model_code,
            'normalizer_fitby': self.normalizer_fitby,
            'normalizer_kwargs': self.normalizer_kwargs,
            'predictor_model_code': self.predictor_model_code,
            'predictor_fitby': self.predictor_fitby,
            'predictor_kwargs': self.predictor_kwargs,
            'predictor_skipnfold_outof_kfold': self.predictor_skipnfold_outof_kfold,
            'predictor_param_grid': self.predictor_param_grid,
            'predictor_validation_score': self.predictor_validation_score,
            'fitting_code': self.fitting_code
        }
        if 'dirfile_features_path' in self._meta:
            d['dirfile_features_path'] = self._meta['dirfile_features_path']
        return d

    @property
    def dir_data(self):
        return os.path.join(self._fitting_base_dir, "res_models", self.fitting_code)

    @property
    def fitting_code(self):
        if self._fitting_code:
            return self._fitting_code
        else:
            if self.fitting_x_feature is None or self.fitting_y_feature is None:
                raise ValueError("fitting_code deduction relies on file path of x_list_dirfile_features and y_list_dirfile_features")
            visible_names = [
                self.fitting_x_feature,
                self.fitting_y_feature,
                self.normalizer_model_code,
                self.normalizer_fitby,
                self.predictor_model_code,
                self.predictor_fitby
            ]
            all_names = [
                self.fitting_x_feature,
                self.fitting_y_feature,
                self.fitting_z_feature,
                self.fitting_w_feature,
                self.fitting_mask,
                self.rolling_start_date,
                self.rolling_window_n_month,
                self.rolling_update_per_n_month,
                self.down_sample_ratio,
                self.down_sample_seed,
                self.normalizer_model_code,
                self.normalizer_fitby,
                self.predictor_model_code,
                self.predictor_fitby,
                self.predictor_skipnfold_outof_kfold,
                self._fitting_base_dir
            ]
            path_hash = hashlib.md5('_'.join(all_names)).hexdigest()
            return '_'.join(visible_names) + "_" + path_hash

    @property
    def fitting_x_feature(self):
        return self._meta.get('x_list_dirfile_features', None)

    @property
    def fitting_y_feature(self):
        return self._meta.get('y_list_dirfile_features', None)

    @property
    def fitting_z_feature(self):
        return self._meta.get('z_list_dirfile_features', None)

    @property
    def fitting_w_feature(self):
        return self._meta.get('w_list_dirfile_features', None)

    @property
    def fitting_mask(self):
        return self._meta.get('mask_list_dirfile_features', None)

    @property
    def fitting_normalizer_code(self):
        return self.normalizer_model_code

    @property
    def fitting_normalizer_fitby(self):
        return self.normalizer_fitby

    @property
    def fitting_predictor_code(self):
        return self.predictor_model_code

    @property
    def fitting_predictor_fitby(self):
        return self.predictor_fitby

    @property
    def fitting_aux_config(self):
        """Auxiliary info to be saved in the DB
        """
        return {
            'dirfile_features_path': self._meta['dirfile_features_path']
        }

    def _get_dirfile_features(self, dirfile_features, key):
        """Get the list dirfile_features with different dirfile_features type, and update the information
           in the meta

        Args:
            dirfile_features:
                string: path of a json config file, which provides a callable to return a list of dirfile_features
                list: list of dirfile_features
                dict: callable to return a list of dirfile_features
            key: str, key used in the meta
        Returns:
            the list of dirfile_features
        """
        if dirfile_features is None:
            return None
        elif isinstance(dirfile_features, str):
            config_path = dirfile_features
            self._meta[key] = os.path.basename(config_path).split('.')[-2]
            self._meta.setdefault('dirfile_features_path', {})[key] = config_path
            return make_list_dirfile_features(iom.read_json(config_path))
        elif isinstance(dirfile_features, Sequence):
            return dirfile_features
        elif isinstance(dirfile_features, dict):
            return function_call(**dirfile_features)
        else:
            raise ValueError()

    def get_rolling_slides(self, rolling_end_date, overwrite=False):
        self.rolling_end_date = rolling_end_date
        list_dd = gymutils.exp_setting2rolling_dates(self)
        for start_date, end_date in list_dd:
            fname_normalizer = gymutils.exp_setting2filename_normalizer(self, start_date, end_date)
            fname_predictor = gymutils.exp_setting2filename_predictor(self, start_date, end_date)
            fname_scores = gymutils.exp_setting2filename_scores(self, start_date, end_date)
            fname_meta = gymutils.exp_setting2filename_meta(self, start_date, end_date)

            if not overwrite:
                if ((fname_normalizer is None or iom.path_exists(fname_normalizer)) and
                    iom.path_exists(fname_predictor) and
                    iom.path_exists(fname_scores) and
                    iom.path_exists(fname_meta)):
                    continue
            yield (start_date, end_date)

    def rolling_fit_one_slide(self, start_date, end_date, overwrite=False):
        return rolling_fit_one_slide(self, start_date, end_date, overwrite)


def rolling_fit_one_slide(exp_setting, start_date, end_date, overwrite=False):
    """ One slide of the rolling training.

    Args:
        exp_setting: experimental settings
        start_date, end_date: the boundary dates of this rolling window
    """
    from sklearn.model_selection import ParameterGrid

    # check existence of normalizer & predictor
    fname_normalizer = gymutils.exp_setting2filename_normalizer(exp_setting, start_date, end_date)
    fname_predictor = gymutils.exp_setting2filename_predictor(exp_setting, start_date, end_date)
    fname_scores = gymutils.exp_setting2filename_scores(exp_setting, start_date, end_date)
    fname_meta = gymutils.exp_setting2filename_meta(exp_setting, start_date, end_date)
    if not overwrite:
        if (fname_normalizer is None or os.path.exists(fname_normalizer)) and os.path.exists(fname_predictor):
            logging.debug("Results already exist, thus skip because exp_setting.recal_if_exists is False")
            return True

    dataset = Dataset(
        symbols=exp_setting.symbols,
        x_list_dirfile_features=exp_setting.x_list_dirfile_features,
        y_list_dirfile_features=exp_setting.y_list_dirfile_features,
        z_list_dirfile_features=exp_setting.z_list_dirfile_features,
        w_list_dirfile_features=exp_setting.w_list_dirfile_features,
        mask_list_dirfile_features=exp_setting.mask_list_dirfile_features,
        name_prefix=exp_setting.fitting_code,
        col_name_prefix=exp_setting.raw_data_base_dir
    )
    down_sample_seed = start_date + end_date
    if exp_setting.down_sample_seed is not None:
        down_sample_seed += exp_setting.down_sample_seed

    dataset.load_incremental_by_month(
        start_date,
        end_date,
        down_sample_ratio=exp_setting.down_sample_ratio,
        down_sample_seed=down_sample_seed,
        verbose=True
    )

    skip_n_fold, k_fold = exp_setting.predictor_skipnfold_outof_kfold
    param_grid = list(ParameterGrid(exp_setting.predictor_param_grid))


    do_optuna = False
    if do_optuna:
        x_tsv_train, y_tsv_train, z_tsv_train, w_tsv_train, mask_tsv_train = dataset.get_kfold_timeCV_tsvdata(
            k_fold-1, kfold=k_fold, manner="expanding", usage="train")
        x_tsv_test, y_tsv_test, z_tsv_test, w_tsv_test, mask_tsv_test = dataset.get_kfold_timeCV_tsvdata(
            k_fold-1, kfold=k_fold, manner="expanding", usage="test")
        _, _, this_fold_arr_train_scores, this_fold_arr_test_scores = normalizer_predictor_optuna_fit(
            exp_setting,
            (x_tsv_train, y_tsv_train, z_tsv_train, w_tsv_train, mask_tsv_train),
            (x_tsv_test, y_tsv_test, z_tsv_test, w_tsv_test, mask_tsv_test),
            dataset.cols_x)
        import sys,IPython; IPython.embed(); sys.exit(0)

    fold_grid_train_scores = OrderedDict()
    fold_grid_test_scores = OrderedDict()
    for i_fold in range(skip_n_fold, k_fold):
        x_tsv_train, y_tsv_train, z_tsv_train, w_tsv_train, mask_tsv_train = dataset.get_kfold_timeCV_tsvdata(
            i_fold, kfold=k_fold, manner="expanding", usage="train")
        x_tsv_test, y_tsv_test, z_tsv_test, w_tsv_test, mask_tsv_test = dataset.get_kfold_timeCV_tsvdata(
            i_fold, kfold=k_fold, manner="expanding", usage="test")
        logging.debug("Fitting i_fold={0} of folds {1}--{2}".format(i_fold, skip_n_fold, k_fold))
        _, _, this_fold_arr_train_scores, this_fold_arr_test_scores = normalizer_predictor_fit_param_grid(
            exp_setting,
            param_grid,
            (x_tsv_train, y_tsv_train, z_tsv_train, w_tsv_train, mask_tsv_train),
            (x_tsv_test, y_tsv_test, z_tsv_test, w_tsv_test, mask_tsv_test),
            dataset.cols_x)
        for _k, _v in this_fold_arr_train_scores.items():
            fold_grid_train_scores[_k] = fold_grid_train_scores.get(_k, []) + [_v.reshape([1,-1])]
        for _k, _v in this_fold_arr_test_scores.items():
            fold_grid_test_scores[_k] = fold_grid_test_scores.get(_k, []) + [_v.reshape([1,-1])]
        gc.collect()
    for _k in fold_grid_train_scores.keys():
        fold_grid_train_scores[_k] = pd.DataFrame(
            np.concatenate(fold_grid_train_scores[_k], 0),
            columns=[_.__repr__() for _ in param_grid]
        )
        fold_grid_test_scores[_k] = pd.DataFrame(
            np.concatenate(fold_grid_test_scores[_k], 0),
            columns=[_.__repr__() for _ in param_grid]
        )

    # select best based on highest average test scores of all folds
    i_best_param = (
        list(fold_grid_test_scores["score"].columns)
        .index(fold_grid_test_scores["score"].mean().idxmax())
    )
    best_param = param_grid[i_best_param]
    logging.info("Best validation param setting: {}".format(best_param))

    # fit by this best param and return it
    m_normalizer, m_predictor, train_scores, _ = normalizer_predictor_fit_param_grid(
        exp_setting,
        [best_param],
        dataset.get_tsvdata_all(),
        (None, None, None, None, None),
        dataset.cols_x)
    assert len(m_predictor) == len(train_scores["score"]) == 1
    m_predictor = m_predictor[0]
    res_scores_dict = {
        "best_param": best_param,
        "train_score_best_param": train_scores,
        "fold_grid_train_scores": fold_grid_train_scores,
        "fold_grid_test_scores": fold_grid_test_scores,
    }

    # save normalizer model, best predictor model, and necessary scores
    iom.mkdirs(gymutils.exp_setting2dir_models(exp_setting))
    if m_normalizer is not None:
        iom.write_pickle(m_normalizer, fname_normalizer)
    iom.write_pickle(m_predictor, fname_predictor)
    iom.write_pickle(res_scores_dict, fname_scores)
    iom.write_json(exp_setting.meta, fname_meta, indent=2, sort_keys=True)
    logging.info("normalizer, best predictor, and scores for slide {0}--{1} have breen saved in {2}".format(
        start_date, end_date, gymutils.exp_setting2dir_models(exp_setting)
    ))
    return m_normalizer, m_predictor


def normalizer_predictor_optuna_fit(exp_setting, xyzwm_tsv_train, xyzwm_tsv_test, cols_x):
    """Enumerate throughout the param_grid, train on train data, test on test data (if there is).

    Args:
        exp_setting: the experiment setting
        xyzwm_tsv_train: tuple, (x_tsv, y_tsv, z_tsv, w_tsv, mask_tsv) for training
        xyzwm_tsv_test: tuple, (x_tsv, y_tsv, z_tsv, w_tsv, mask_tsv) for testing
        cols_x: list of strings to indicate the feature names of x
    Returns:
        m_normalizer: None, or normalizer object, or dict with values being normalizer objects
        list_m_predictors: list of predictor objects, one by one corresponding to param_grid
        dict_train_scores: dict of array of training scores, each key is a metric, each array corresponds one by one to param_grid
        dict_test_scores: dict of array of testing scores, each key is a metric, each array corresponds one by one to param_grid
    """
    import lightgbm as lgb
    import optuna
    from optuna.integration import LightGBMPruningCallback
    from stml_mft_china_eq.pyutils.timer import Timer
    from stml_mft_china_eq.pyutils.custom_logger import CustomLogger

    x_tsv_train, y_tsv_train, z_tsv_train, w_tsv_train, mask_tsv_train = xyzwm_tsv_train
    x_tsv_test, y_tsv_test, z_tsv_test, w_tsv_test, mask_tsv_test = xyzwm_tsv_test

    # normalizer fitting
    m_normalizer = None
    if exp_setting.normalizer_model_code is not None:
        logging.debug("Fitting normalizer")
        if exp_setting.normalizer_model_code.lower() == "znorm":
            c_normalizer = ZNormalizer
        elif exp_setting.normalizer_model_code.lower() == "qnorm":
            c_normalizer = QNormalizer
        else:
            raise NotImplementedError()

        if exp_setting.normalizer_fitby == "universe":
            x_mat_train = gymutils.tsv2nv(x_tsv_train)
            if mask_tsv_train is not None:
                if mask_tsv_train.shape[2] > 1:
                    mask_tsv_train = np.prod(mask_tsv_train, axis=2, keepdims=True).astype(TYPE_INT)
                idx_valid_train = mask_tsv_train.reshape([-1])>0
                x_mat_train = x_mat_train[idx_valid_train,:]
            if x_mat_train.shape[0] > THRES_NONZERO_SIZE:
                m_normalizer = c_normalizer(**exp_setting.normalizer_kwargs)
            else:
                m_normalizer = ZeroNormalizer()
            m_normalizer.fit(x_mat_train, cols_x)
            x_tsv_train = (
                m_normalizer.transform(gymutils.tsv2nv(x_tsv_train), cols_x)
                .reshape(x_tsv_train.shape)
            )
            if x_tsv_test is not None:
                x_tsv_test = (
                    m_normalizer.transform(gymutils.tsv2nv(x_tsv_test), cols_x)
                    .reshape(x_tsv_test.shape)
                )
        elif exp_setting.normalizer_fitby == "sector":
            raise NotImplementedError()
        elif exp_setting.normalizer_fitby == "symbol":
            raise NotImplementedError()
        else:
            raise NotImplementedError()

    # predictor fitting
    logging.debug("Fitting predictor")
    list_m_predictors = []
    dict_train_scores = OrderedDict()
    dict_test_scores = OrderedDict()
    if exp_setting.predictor_fitby == "universe":
        x_nv_train, y_nv_train, z_nv_train, w_nv_train = gymutils.xyzwm_tsv2xyzw_nv(
            x_tsv_train, y_tsv_train, z_tsv_train, w_tsv_train, mask_tsv_train
        )
        x_nv_test, y_nv_test, z_nv_test, w_nv_test = gymutils.xyzwm_tsv2xyzw_nv(
            x_tsv_test, y_tsv_test, z_tsv_test, w_tsv_test, mask_tsv_test
        )
        def optuna_objective(trial):
            param_grid = {
                "n_estimators": trial.suggest_categorical("n_estimators", [100, 500, 1000]),
                "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.3),
                "max_bin": trial.suggest_int("max_bin", 17, 63, step=16),
                "num_leaves": trial.suggest_int("num_leaves", 20, 3000, step=20),
                "max_depth": trial.suggest_int("max_depth", 3, 12),
                "min_data_in_leaf": trial.suggest_int("min_data_in_leaf", 200, 10000, step=100),
                "lambda_l1": trial.suggest_int("lambda_l1", 0, 100, step=5),
                "lambda_l2": trial.suggest_int("lambda_l2", 0, 100, step=5),
                "min_gain_to_split": trial.suggest_float("min_gain_to_split", 0, 15),
                "bagging_fraction": trial.suggest_float(
                    "bagging_fraction", 0.2, 0.9, step=0.1
                ),
                "bagging_freq": trial.suggest_categorical("bagging_freq", [1]),
                "feature_fraction": trial.suggest_float(
                    "feature_fraction", 0.2, 0.9, step=0.1
                ),
            }
            model = lgb.LGBMRegressor(**param_grid)
            model.fit(
                x_nv_train, y_nv_train.reshape([-1]),
                eval_set=[(x_nv_test, y_nv_test)],
                eval_metric="l2",
                early_stopping_rounds=200,
                callbacks=[LightGBMPruningCallback(trial, "l2")]
            )
            yhat_test = model.predict(x_nv_test)
            return np.mean((yhat_test.reshape([-1]) - y_nv_test.reshape([-1]))**2)
            # return np.mean((yhat_test.reshape([-1]) * y_nv_test.reshape([-1]))) \
            #     / np.sqrt(np.mean(y_nv_test**2))

        logger = CustomLogger(name="my_custom_logger", verbose=True, log_dir=None)
        t = Timer(name="class usage", logger=logger.info)
        study = optuna.create_study(direction="minimize", study_name="test opt")
        # study = optuna.create_study(direction="maximize", study_name="test opt")
        func = lambda trial: optuna_objective(trial)
        t.tic()
        study.optimize(func, n_trials=60)
        t.toc()

        import sys,IPython; IPython.embed(); sys.exit(0)


        for i_grid, grid_kwargs in enumerate(param_grid):
            this_m_predictor, this_train_scores, this_test_scores = predictor_fit_grid_point(
                exp_setting,
                grid_kwargs,
                (x_nv_train, y_nv_train, z_nv_train, w_nv_train),
                (x_nv_test, y_nv_test, z_nv_test, w_nv_test),
                gram_x_train=gram_x_train
            )
            list_m_predictors.append(this_m_predictor)
            for _k, _v in this_train_scores.items():
                _train_scores = dict_train_scores.get(_k, np.empty(len(param_grid)))
                _train_scores[i_grid] = _v
                dict_train_scores[_k] = _train_scores
            for _k, _v in this_test_scores.items():
                _test_scores = dict_test_scores.get(_k, np.empty(len(param_grid)))
                _test_scores[i_grid] = _v
                dict_test_scores[_k] = _test_scores

        return m_normalizer, list_m_predictors, dict_train_scores, dict_test_scores
    elif exp_setting.predictor_fitby == "sector":
        raise NotImplementedError()
        sector2symbols, sector2idx_symbols = {}, {}
        symbol2sector = {}
        for sector in []:
            symbols_this_sector = exp_setting.static_data.get_symbols_meta_manual(sector=sector)["symbol"].values
            if len(symbols_this_sector) == 0:
                continue
            sector2symbols[sector] = list(symbols_this_sector)
            sector2idx_symbols[sector] = [exp_setting.symbols.index(symbol) for symbol in symbols_this_sector]
            for symbol in symbols_this_sector:
                symbol2sector[symbol] = sector
        # TODO: swap the order of grid and fitby sector, so that the precompute is calculated more efficiently
        for i_grid, grid_kwargs in enumerate(param_grid):
            sector2m_predictor = {}
            sector2train_scores, sector2test_scores = {}, {}
            for sector in sector2idx_symbols.keys():
                x_nv_train, y_nv_train, z_nv_train, w_nv_train = gymutils.xyzwm_tsv2xyzw_nv(
                    gymutils.tsv2subsymbols_tsv(x_tsv_train, sector2idx_symbols[sector]),
                    gymutils.tsv2subsymbols_tsv(y_tsv_train, sector2idx_symbols[sector]),
                    gymutils.tsv2subsymbols_tsv(z_tsv_train, sector2idx_symbols[sector]),
                    gymutils.tsv2subsymbols_tsv(w_tsv_train, sector2idx_symbols[sector]),
                    gymutils.tsv2subsymbols_tsv(mask_tsv_train, sector2idx_symbols[sector])
                )
                if x_tsv_test is not None:
                    x_nv_test, y_nv_test, z_nv_test, w_nv_test = gymutils.xyzwm_tsv2xyzw_nv(
                        gymutils.tsv2subsymbols_tsv(x_tsv_test, sector2idx_symbols[sector]),
                        gymutils.tsv2subsymbols_tsv(y_tsv_test, sector2idx_symbols[sector]),
                        gymutils.tsv2subsymbols_tsv(z_tsv_test, sector2idx_symbols[sector]),
                        gymutils.tsv2subsymbols_tsv(w_tsv_test, sector2idx_symbols[sector]),
                        gymutils.tsv2subsymbols_tsv(mask_tsv_test, sector2idx_symbols[sector])
                    )
                else:
                    x_nv_test, y_nv_test, z_nv_test, w_nv_test = None, None, None, None
                if x_nv_train.shape[0] > THRES_NONZERO_SIZE and (x_nv_test is None or x_nv_test.shape[0] > THRES_NONZERO_SIZE):
                    sector2m_predictor[sector], sector2train_scores[sector], sector2test_scores[sector] = predictor_fit_grid_point(
                        exp_setting,
                        grid_kwargs,
                        (x_nv_train, y_nv_train, z_nv_train, w_nv_train),
                        (x_nv_test, y_nv_test, z_nv_test, w_nv_test)
                    )
            list_m_predictors.append(sector2m_predictor)
            for _k in sector2train_scores.values()[0].keys():
                _train_scores = dict_train_scores.get(_k, np.empty(len(param_grid)))
                _train_scores[i_grid] = np.nanmean([
                    sector2train_scores[sector][_k]
                    for sector in sector2train_scores.keys()
                ])
                dict_train_scores[_k] = _train_scores
            for _k in sector2test_scores.values()[0].keys():
                _test_scores = dict_test_scores.get(_k, np.empty(len(param_grid)))
                _test_scores[i_grid] = np.nanmean([
                    sector2test_scores[sector][_k]
                    for sector in sector2test_scores.keys()
                ])
                dict_test_scores[_k] = _test_scores

        return m_normalizer, list_m_predictors, dict_train_scores, dict_test_scores
    elif exp_setting.predictor_fitby == "symbol":
        raise NotImplementedError()
        # TODO: swap the order of grid and fitby symbol, so that the precompute is calculated more efficiently
        for i_grid, grid_kwargs in enumerate(param_grid):
            symbol2m_predictor = {}
            symbol2train_scores, symbol2test_scores = {}, {}
            for i_symbol, symbol in enumerate(exp_setting.symbols):
                x_nv_train, y_nv_train, z_nv_train, w_nv_train = gymutils.xyzwm_tsv2xyzw_nv(
                    gymutils.tsv2subsymbols_tsv(x_tsv_train, [i_symbol]),
                    gymutils.tsv2subsymbols_tsv(y_tsv_train, [i_symbol]),
                    gymutils.tsv2subsymbols_tsv(z_tsv_train, [i_symbol]),
                    gymutils.tsv2subsymbols_tsv(w_tsv_train, [i_symbol]),
                    gymutils.tsv2subsymbols_tsv(mask_tsv_train, [i_symbol])
                )
                if x_tsv_test is not None:
                    x_nv_test, y_nv_test, z_nv_test, w_nv_test = gymutils.xyzwm_tsv2xyzw_nv(
                        gymutils.tsv2subsymbols_tsv(x_tsv_test, [i_symbol]),
                        gymutils.tsv2subsymbols_tsv(y_tsv_test, [i_symbol]),
                        gymutils.tsv2subsymbols_tsv(z_tsv_test, [i_symbol]),
                        gymutils.tsv2subsymbols_tsv(w_tsv_test, [i_symbol]),
                        gymutils.tsv2subsymbols_tsv(mask_tsv_test, [i_symbol])
                    )
                else:
                    x_nv_test, y_nv_test, z_nv_test, w_nv_test = None, None, None, None
                if x_nv_train.shape[0] > THRES_NONZERO_SIZE and (x_nv_test is None or x_nv_test.shape[0] > THRES_NONZERO_SIZE):
                    symbol2m_predictor[symbol], symbol2train_scores[symbol], symbol2test_scores[symbol] = predictor_fit_grid_point(
                        exp_setting,
                        grid_kwargs,
                        (x_nv_train, y_nv_train, z_nv_train, w_nv_train),
                        (x_nv_test, y_nv_test, z_nv_test, w_nv_test)
                    )
            list_m_predictors.append(symbol2m_predictor)
            for _k in symbol2train_scores.values()[0].keys():
                _train_scores = dict_train_scores.get(_k, np.empty(len(param_grid)))
                _train_scores[i_grid] = np.nanmean([
                    symbol2train_scores[symbol][_k]
                    for symbol in symbol2train_scores.keys()
                ])
                dict_train_scores[_k] = _train_scores
            for _k in symbol2test_scores.values()[0].keys():
                _test_scores = dict_test_scores.get(_k, np.empty(len(param_grid)))
                _test_scores[i_grid] = np.nanmean([
                    symbol2test_scores[symbol][_k]
                    for symbol in symbol2test_scores.keys()
                ])
                dict_test_scores[_k] = _test_scores

        return m_normalizer, list_m_predictors, dict_train_scores, dict_test_scores
    else:
        raise NotImplementedError()


def normalizer_predictor_fit_param_grid(exp_setting, param_grid, xyzwm_tsv_train, xyzwm_tsv_test, cols_x):
    """Enumerate throughout the param_grid, train on train data, test on test data (if there is).

    Args:
        exp_setting: the experiment setting
        param_grid: grid of parameters of the predictor to fit.
        xyzwm_tsv_train: tuple, (x_tsv, y_tsv, z_tsv, w_tsv, mask_tsv) for training
        xyzwm_tsv_test: tuple, (x_tsv, y_tsv, z_tsv, w_tsv, mask_tsv) for testing
        cols_x: list of strings to indicate the feature names of x
    Returns:
        m_normalizer: None, or normalizer object, or dict with values being normalizer objects
        list_m_predictors: list of predictor objects, one by one corresponding to param_grid
        dict_train_scores: dict of array of training scores, each key is a metric, each array corresponds one by one to param_grid
        dict_test_scores: dict of array of testing scores, each key is a metric, each array corresponds one by one to param_grid
    """
    x_tsv_train, y_tsv_train, z_tsv_train, w_tsv_train, mask_tsv_train = xyzwm_tsv_train
    x_tsv_test, y_tsv_test, z_tsv_test, w_tsv_test, mask_tsv_test = xyzwm_tsv_test

    # normalizer fitting
    m_normalizer = None
    if exp_setting.normalizer_model_code is not None:
        logging.debug("Fitting normalizer")
        if exp_setting.normalizer_model_code.lower() == "znorm":
            c_normalizer = ZNormalizer
        elif exp_setting.normalizer_model_code.lower() == "qnorm":
            c_normalizer = QNormalizer
        else:
            raise NotImplementedError()

        if exp_setting.normalizer_fitby == "universe":
            x_mat_train = gymutils.tsv2nv(x_tsv_train)
            if mask_tsv_train is not None:
                if mask_tsv_train.shape[2] > 1:
                    mask_tsv_train = np.prod(mask_tsv_train, axis=2, keepdims=True).astype(TYPE_INT)
                idx_valid_train = mask_tsv_train.reshape([-1])>0
                x_mat_train = x_mat_train[idx_valid_train,:]
            if x_mat_train.shape[0] > THRES_NONZERO_SIZE:
                m_normalizer = c_normalizer(**exp_setting.normalizer_kwargs)
            else:
                m_normalizer = ZeroNormalizer()
            m_normalizer.fit(x_mat_train, cols_x)
            x_tsv_train = (
                m_normalizer.transform(gymutils.tsv2nv(x_tsv_train), cols_x)
                .reshape(x_tsv_train.shape)
            )
            if x_tsv_test is not None:
                x_tsv_test = (
                    m_normalizer.transform(gymutils.tsv2nv(x_tsv_test), cols_x)
                    .reshape(x_tsv_test.shape)
                )
        elif exp_setting.normalizer_fitby == "sector":
            raise NotImplementedError()
        elif exp_setting.normalizer_fitby == "symbol":
            raise NotImplementedError()
        else:
            raise NotImplementedError()

    # predictor fitting
    logging.debug("Fitting predictor")
    list_m_predictors = []
    dict_train_scores = OrderedDict()
    dict_test_scores = OrderedDict()
    if exp_setting.predictor_fitby == "universe":
        x_nv_train, y_nv_train, z_nv_train, w_nv_train = gymutils.xyzwm_tsv2xyzw_nv(
            x_tsv_train, y_tsv_train, z_tsv_train, w_tsv_train, mask_tsv_train
        )
        x_nv_test, y_nv_test, z_nv_test, w_nv_test = gymutils.xyzwm_tsv2xyzw_nv(
            x_tsv_test, y_tsv_test, z_tsv_test, w_tsv_test, mask_tsv_test
        )
        gram_x_train = np.dot(x_nv_train.T, x_nv_train)
        gram_x_train[~np.isfinite(gram_x_train)] = 0.0
        for i_grid, grid_kwargs in enumerate(param_grid):
            this_m_predictor, this_train_scores, this_test_scores = predictor_fit_grid_point(
                exp_setting,
                grid_kwargs,
                (x_nv_train, y_nv_train, z_nv_train, w_nv_train),
                (x_nv_test, y_nv_test, z_nv_test, w_nv_test),
                gram_x_train=gram_x_train
            )
            list_m_predictors.append(this_m_predictor)
            for _k, _v in this_train_scores.items():
                _train_scores = dict_train_scores.get(_k, np.empty(len(param_grid)))
                _train_scores[i_grid] = _v
                dict_train_scores[_k] = _train_scores
            for _k, _v in this_test_scores.items():
                _test_scores = dict_test_scores.get(_k, np.empty(len(param_grid)))
                _test_scores[i_grid] = _v
                dict_test_scores[_k] = _test_scores

        return m_normalizer, list_m_predictors, dict_train_scores, dict_test_scores
    elif exp_setting.predictor_fitby == "sector":
        raise NotImplementedError()
        sector2symbols, sector2idx_symbols = {}, {}
        symbol2sector = {}
        for sector in []:
            symbols_this_sector = exp_setting.static_data.get_symbols_meta_manual(sector=sector)["symbol"].values
            if len(symbols_this_sector) == 0:
                continue
            sector2symbols[sector] = list(symbols_this_sector)
            sector2idx_symbols[sector] = [exp_setting.symbols.index(symbol) for symbol in symbols_this_sector]
            for symbol in symbols_this_sector:
                symbol2sector[symbol] = sector
        # TODO: swap the order of grid and fitby sector, so that the precompute is calculated more efficiently
        for i_grid, grid_kwargs in enumerate(param_grid):
            sector2m_predictor = {}
            sector2train_scores, sector2test_scores = {}, {}
            for sector in sector2idx_symbols.keys():
                x_nv_train, y_nv_train, z_nv_train, w_nv_train = gymutils.xyzwm_tsv2xyzw_nv(
                    gymutils.tsv2subsymbols_tsv(x_tsv_train, sector2idx_symbols[sector]),
                    gymutils.tsv2subsymbols_tsv(y_tsv_train, sector2idx_symbols[sector]),
                    gymutils.tsv2subsymbols_tsv(z_tsv_train, sector2idx_symbols[sector]),
                    gymutils.tsv2subsymbols_tsv(w_tsv_train, sector2idx_symbols[sector]),
                    gymutils.tsv2subsymbols_tsv(mask_tsv_train, sector2idx_symbols[sector])
                )
                if x_tsv_test is not None:
                    x_nv_test, y_nv_test, z_nv_test, w_nv_test = gymutils.xyzwm_tsv2xyzw_nv(
                        gymutils.tsv2subsymbols_tsv(x_tsv_test, sector2idx_symbols[sector]),
                        gymutils.tsv2subsymbols_tsv(y_tsv_test, sector2idx_symbols[sector]),
                        gymutils.tsv2subsymbols_tsv(z_tsv_test, sector2idx_symbols[sector]),
                        gymutils.tsv2subsymbols_tsv(w_tsv_test, sector2idx_symbols[sector]),
                        gymutils.tsv2subsymbols_tsv(mask_tsv_test, sector2idx_symbols[sector])
                    )
                else:
                    x_nv_test, y_nv_test, z_nv_test, w_nv_test = None, None, None, None
                if x_nv_train.shape[0] > THRES_NONZERO_SIZE and (x_nv_test is None or x_nv_test.shape[0] > THRES_NONZERO_SIZE):
                    sector2m_predictor[sector], sector2train_scores[sector], sector2test_scores[sector] = predictor_fit_grid_point(
                        exp_setting,
                        grid_kwargs,
                        (x_nv_train, y_nv_train, z_nv_train, w_nv_train),
                        (x_nv_test, y_nv_test, z_nv_test, w_nv_test)
                    )
            list_m_predictors.append(sector2m_predictor)
            for _k in sector2train_scores.values()[0].keys():
                _train_scores = dict_train_scores.get(_k, np.empty(len(param_grid)))
                _train_scores[i_grid] = np.nanmean([
                    sector2train_scores[sector][_k]
                    for sector in sector2train_scores.keys()
                ])
                dict_train_scores[_k] = _train_scores
            for _k in sector2test_scores.values()[0].keys():
                _test_scores = dict_test_scores.get(_k, np.empty(len(param_grid)))
                _test_scores[i_grid] = np.nanmean([
                    sector2test_scores[sector][_k]
                    for sector in sector2test_scores.keys()
                ])
                dict_test_scores[_k] = _test_scores

        return m_normalizer, list_m_predictors, dict_train_scores, dict_test_scores
    elif exp_setting.predictor_fitby == "symbol":
        raise NotImplementedError()
        # TODO: swap the order of grid and fitby symbol, so that the precompute is calculated more efficiently
        for i_grid, grid_kwargs in enumerate(param_grid):
            symbol2m_predictor = {}
            symbol2train_scores, symbol2test_scores = {}, {}
            for i_symbol, symbol in enumerate(exp_setting.symbols):
                x_nv_train, y_nv_train, z_nv_train, w_nv_train = gymutils.xyzwm_tsv2xyzw_nv(
                    gymutils.tsv2subsymbols_tsv(x_tsv_train, [i_symbol]),
                    gymutils.tsv2subsymbols_tsv(y_tsv_train, [i_symbol]),
                    gymutils.tsv2subsymbols_tsv(z_tsv_train, [i_symbol]),
                    gymutils.tsv2subsymbols_tsv(w_tsv_train, [i_symbol]),
                    gymutils.tsv2subsymbols_tsv(mask_tsv_train, [i_symbol])
                )
                if x_tsv_test is not None:
                    x_nv_test, y_nv_test, z_nv_test, w_nv_test = gymutils.xyzwm_tsv2xyzw_nv(
                        gymutils.tsv2subsymbols_tsv(x_tsv_test, [i_symbol]),
                        gymutils.tsv2subsymbols_tsv(y_tsv_test, [i_symbol]),
                        gymutils.tsv2subsymbols_tsv(z_tsv_test, [i_symbol]),
                        gymutils.tsv2subsymbols_tsv(w_tsv_test, [i_symbol]),
                        gymutils.tsv2subsymbols_tsv(mask_tsv_test, [i_symbol])
                    )
                else:
                    x_nv_test, y_nv_test, z_nv_test, w_nv_test = None, None, None, None
                if x_nv_train.shape[0] > THRES_NONZERO_SIZE and (x_nv_test is None or x_nv_test.shape[0] > THRES_NONZERO_SIZE):
                    symbol2m_predictor[symbol], symbol2train_scores[symbol], symbol2test_scores[symbol] = predictor_fit_grid_point(
                        exp_setting,
                        grid_kwargs,
                        (x_nv_train, y_nv_train, z_nv_train, w_nv_train),
                        (x_nv_test, y_nv_test, z_nv_test, w_nv_test)
                    )
            list_m_predictors.append(symbol2m_predictor)
            for _k in symbol2train_scores.values()[0].keys():
                _train_scores = dict_train_scores.get(_k, np.empty(len(param_grid)))
                _train_scores[i_grid] = np.nanmean([
                    symbol2train_scores[symbol][_k]
                    for symbol in symbol2train_scores.keys()
                ])
                dict_train_scores[_k] = _train_scores
            for _k in symbol2test_scores.values()[0].keys():
                _test_scores = dict_test_scores.get(_k, np.empty(len(param_grid)))
                _test_scores[i_grid] = np.nanmean([
                    symbol2test_scores[symbol][_k]
                    for symbol in symbol2test_scores.keys()
                ])
                dict_test_scores[_k] = _test_scores

        return m_normalizer, list_m_predictors, dict_train_scores, dict_test_scores
    else:
        raise NotImplementedError()


def predictor_fit_grid_point(exp_setting, grid_kwargs, xyzw_nv_train, xyzw_nv_test, gram_x_train=None):
    """Fit predictor on just on parameter grid.

    Args:
        exp_setting: the experiment setting
        grid_kwargs: dict, one grid point of parameters of the predictor to fit
        xyzw_nv_train: tuple, (x_nv, y_nv, z_nv, w_nv) for training
        xyzw_nv_test: tuple, (x_nv, y_nv, z_nv, w_nv) for testing
        gram_x_train: None or array, (n_dim_x, n_dim_x) gram matrix of X, np.dot(x_nv.T, x_nv)
    Returns:
        m_predictor: resulted predictor object
        scores_train: training score dict, each key is a metric, each value is a scalar
        scores_test: testing score dict, each key is a metric, each value is a scalar
    """
    x_nv_train, y_nv_train, z_nv_train, w_nv_train = xyzw_nv_train
    x_nv_test, y_nv_test, z_nv_test, w_nv_test = xyzw_nv_test

    kwargs = exp_setting.predictor_kwargs.copy()
    kwargs.update(grid_kwargs)

    if exp_setting.predictor_model_code.lower() in gymutils.LIST_PREDICTORS_LINEAR:
        if False:
            if gram_x_train is None:
                # NOTE: this part may lead to a bug of tolerance check in sklearn for float32 dtype.
                # See https://github.com/scikit-learn/scikit-learn/pull/22059 for details.
                # We temporarily disable it here. But may use our precomput for float32 in future.
                gram_x_train = np.empty(shape=(x_nv_train.shape[1], x_nv_train.shape[1]),
                                        dtype=x_nv_train.dtype, order='C')
                np.dot(x_nv_train.T, x_nv_train, out=gram_x_train)
            gram_x_train = None
            kwargs.update({"precompute": gram_x_train})

    m_predictor = predictors.make_predictor(exp_setting.predictor_model_code, **kwargs)

    if exp_setting.predictor_model_code.lower() in ["ridge", "lasso", "elasticnet", "wtridge", "wtlasso", "wtelasticnet", "xgb", "lgb", "rf"]:
        try:
            # demean for reducing bias, no flip for higher correlation (while some features may need flip for augmentation)
            m_predictor.fit(x_nv_train, y_nv_train, sample_weight=w_nv_train, bool_demean=True, bool_flip_aug=False)
        except TypeError:
            # sample_weight argument is not supported
            m_predictor.fit(x_nv_train, y_nv_train, bool_demean=True, bool_flip_aug=False)
    elif exp_setting.predictor_model_code.lower() in ["mmridge", "mmlasso", "mmelasticnet", "robmmridge", "robmmlasso", "robmmelasticnet"]:
        try:
            m_predictor.fit(x_nv_train, y_nv_train, z_nv_train, sample_weight=w_nv_train, verbose=True)
        except TypeError:
            # sample_weight argument is not supported
            m_predictor.fit(x_nv_train, y_nv_train, z_nv_train, verbose=True)
    elif exp_setting.predictor_model_code.lower().startswith("todmoe"):
        raise NotImplementedError()
        #TODO: pass intervals into TODMOE? (append column to x_nv_train may be good)
    else:
        raise NotImplementedError()

    list_metrics_eval_stats = ["mean", "median", "std", "skew", "kurt", "min", "max", "mean/std", "p(neg)", "p(zero)", "p(pos)"]
    list_metrics_eval_regression = ["MSE", "RelMSE", "R2", "CorrR", "IC1", "IC2", "SpearmanRho", "CC", "slope", "Q(RET)"]
    yhat_nv_train = m_predictor.predict(x_nv_train)
    scores_train = gym_eval.eval_regression(
        y_nv_train, yhat_nv_train, list_metrics=list_metrics_eval_regression, is_res_dataframe=False)
    scores_train.update(gym_eval.eval_stats(
        yhat_nv_train, key_prefix="yhat.", list_metrics=list_metrics_eval_stats, is_res_dataframe=False))
    scores_train.update(gym_eval.eval_stats(
        y_nv_train, key_prefix="y.", list_metrics=list_metrics_eval_stats, is_res_dataframe=False))
    if exp_setting.predictor_validation_score is None:
        scores_train["score"] = m_predictor.score(x_nv_train, y_nv_train, sample_weight=w_nv_train)
    else:
        scores_train["score"] = scores_train[exp_setting.predictor_validation_score]

    if x_nv_test is not None:
        yhat_nv_test = m_predictor.predict(x_nv_test)
        scores_test = gym_eval.eval_regression(
            y_nv_test, yhat_nv_test, list_metrics=list_metrics_eval_regression, is_res_dataframe=False)
        scores_test.update(gym_eval.eval_stats(
            yhat_nv_test, key_prefix="yhat.", list_metrics=list_metrics_eval_stats, is_res_dataframe=False))
        scores_test.update(gym_eval.eval_stats(
            y_nv_test, key_prefix="y.", list_metrics=list_metrics_eval_stats, is_res_dataframe=False))
        if exp_setting.predictor_validation_score is None:
            scores_test["score"] = m_predictor.score(x_nv_test, y_nv_test, sample_weight=w_nv_test)
        else:
            scores_test["score"] = scores_test[exp_setting.predictor_validation_score]
    else:
        scores_test = {}

    logging.debug("Finished fitting predictor with grid_kwargs={0}, score_train={1}, score_test={2}".format(
        grid_kwargs, scores_train.get("score", None), scores_test.get("score", None)))
    return m_predictor, scores_train, scores_test
