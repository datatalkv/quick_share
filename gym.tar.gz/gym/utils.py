# -*- coding: utf-8 -*-
"""
Utils for gym, feature extraction, fitting, prediction etc
"""
import os
from collections import OrderedDict
import numpy as np
import pandas as pd
import logging
import argparse
import datetime

from stml_mft_china_eq.pyutils import iom
from stml_mft_china_eq.pyutils import datetime_utils as dtu
from stml_mft_china_eq.configs import const


LIST_STR_MONTHS = [
    "{0:04d}{1:02d}".format(YYYY, MM)
    for YYYY in range(2000, 2050)
    for MM in range(1, 13)
]

LIST_PREDICTORS_LINEAR = ["ridge", "lasso", "elasticnet", "mmridge", "mmlasso", "mmelasticnet", "robmmridge", "robmmlasso", "robmmelasticnet"]
LIST_PREDICTORS_TREE = ["xgb", "lgb", "rf"]

LIST_NORMALIZERS = ["znorm", "qnorm"]


def get_exp_setting(file_exp_setting):
    """Note: file_exp_setting is a python script file, claiming the experiment configs.
    It is currently awkward in .py for convenience, which may be changed into json or xml in future.
    """
    # import imp
    # exp_setting = imp.load_source("exp_setting", file_exp_setting)
    import importlib.machinery
    loader = importlib.machinery.SourceFileLoader("exp_setting", file_exp_setting)
    exp_setting = loader.load_module()
    list_attr_check = [
        "x_list_dirfile_features",
        "y_list_dirfile_features",
        "z_list_dirfile_features",
        "w_list_dirfile_features",
        "mask_list_dirfile_features",
        "rolling_start_date",
        "rolling_end_date",
        "rolling_update_per_n_month",
        "rolling_window_n_month",
        "symbols",
        "down_sample_ratio",
        "down_sample_seed",
        "normalizer_model_code",
        "normalizer_fitby",
        "normalizer_kwargs",
        "predictor_model_code",
        "predictor_fitby",
        "predictor_kwargs",
        "predictor_skipnfold_outof_kfold",
        "predictor_param_grid",
        "predictor_validation_score",
        "recal_if_exists",
    ]
    for attr_check in list_attr_check:
        if not hasattr(exp_setting, attr_check):
            raise ValueError("exp_setting in file {0} missed attribute {1}".format(
                file_exp_setting, attr_check
            ))

    return exp_setting

def _is_or_beyond_last_weekday(date, weekdays_only):
    dates = dtu.date_range_china_eq(
        date, dtu.last_day_of_month(dtu.to_date_str(date)[:6]), weekdays_only=weekdays_only)
    return len(dates) == 0 or (len(dates) == 1 and dates[0] == dtu.coerce_date(date))

def exp_setting2rolling_dates(exp_setting):
    """Generate list of (start_date, end_date) based on rolling training setting"""
    rolling_start_month = dtu.to_date_str(exp_setting.rolling_start_date)[:6]
    rolling_end_date = dtu.to_date_obj(exp_setting.rolling_end_date)
    if not _is_or_beyond_last_weekday(rolling_end_date, weekdays_only=exp_setting.weekdays_only):
        prev_month = dtu.prev_month(dtu.to_date_str(rolling_end_date)[:6])
        rolling_end_date = dtu.last_day_of_month(prev_month)
    rolling_end_month = dtu.to_date_str(rolling_end_date)[:6]
    i_rolling_start_month = LIST_STR_MONTHS.index(rolling_start_month)
    i_rolling_end_month = LIST_STR_MONTHS.index(rolling_end_month)

    i_start_month = i_rolling_start_month
    res = []
    while i_start_month + exp_setting.rolling_window_n_month - 1 <= i_rolling_end_month:
        i_end_month = i_start_month + exp_setting.rolling_window_n_month - 1
        this_start_date = dtu.to_date_int(LIST_STR_MONTHS[i_start_month] + "01")
        this_end_date =  dtu.to_date_int(dtu.last_day_of_month(LIST_STR_MONTHS[i_end_month]))
        res.append((this_start_date, this_end_date))
        i_start_month += exp_setting.rolling_update_per_n_month
    return res


def exp_setting2sign(exp_setting):
    return os.path.splitext(os.path.basename(exp_setting.__file__))[0]


def exp_setting2dir_models(exp_setting):
    return exp_setting.dir_data

def exp_setting2filename_normalizer(exp_setting, start_date, end_date):
    if exp_setting.normalizer_model_code is None:
        return None

    if exp_setting.normalizer_model_code.lower() in LIST_NORMALIZERS:
        file_basename = "normalizer_{0}_{1}.pkl".format(start_date, end_date)
    else:
        raise NotImplementedError()
    return os.path.join(
        exp_setting2dir_models(exp_setting),
        file_basename
    )


def exp_setting2filename_predictor(exp_setting, start_date, end_date):
    if exp_setting.predictor_model_code.lower() in LIST_PREDICTORS_LINEAR + LIST_PREDICTORS_TREE:
        file_basename = "predictor_{0}_{1}.pkl".format(start_date, end_date)
    else:
        raise NotImplementedError()

    return os.path.join(
        exp_setting2dir_models(exp_setting),
        file_basename
    )


def exp_setting2filename_scores(exp_setting, start_date, end_date):
    file_basename = "scores_{0}_{1}.pkl".format(start_date, end_date)
    return os.path.join(
        exp_setting2dir_models(exp_setting),
        file_basename
    )

def exp_setting2filename_meta(exp_setting, start_date, end_date):
    file_basename = "meta_{0}_{1}.json".format(start_date, end_date)
    return os.path.join(
        exp_setting2dir_models(exp_setting),
        file_basename
    )


def df2tsv(df, cols_symbols, cols_values, loc_timestamps=None, dtype="float32"):
    """Extract tsv 3d array from a dataframe.

    Args:
        df: (#t, 1+#s*#v) shape dataframe, with columns [COL_TIMESTAMP] + ["{symbol}.{value}" ... ]
        cols_symbols: list of symbol names in the same order of 2nd dim in tsv_array
        cols_values: list of value names in the same order of 3rd dim in tsv_array
        loc_timestamps: None or array, if no None, just pick timestamps according to loc_timestamps
        dtype: dtype of the resulted tsv_array
    Returns:
        tsv_array: (#t, #s, #v) shape array
    """
    if loc_timestamps is None:
        _df = df
    else:
        _df = df.loc[df[const.COL_TIMESTAMP].isin(loc_timestamps)]

    columns = ["{}{}{}".format(col_symbol, const.SEP, col_value) for col_symbol in cols_symbols for col_value in cols_values]
    values = _df[columns].values.astype(dtype)
    return values.reshape([len(df), len(cols_symbols), len(cols_values)])


def tsv2df(tsv_array, timestamps, cols_symbols, cols_values, do_augment_cols_time=True):
    """Shape the tsv data into a dataframe.

    Args:
        tsv_array: 3d array
        timestamps: 1d array, containing the timestamps, in the same order of 1st dim of tsv_array
        cols_symbols: list of symbol names in the same order of 2nd dim in tsv_array
        cols_values: list of value names in the same order of 3rd dim in tsv_array
        do_augment_cols_time: bool, augment columns const.COLS_TIME based on COL_TIMESTAMP
    Returns:
        df: (#t, cols_time+#s*#v) shape dataframe, with columns
                [COL_TIMESTAMP] + (optional time cols) + ["{symbol}.{value}" ... ]
    """
    if len(timestamps) != tsv_array.shape[0]:
        raise ValueError("#timestamps={0} unmatched with tsv_array.shape={1}".format(
            len(timestamps), tsv_array.shape
        ))
    if len(cols_symbols) != tsv_array.shape[1]:
        raise ValueError("#cols_symbols={0} unmatched with tsv_array.shape={1}".format(
            len(cols_symbols), tsv_array.shape
        ))
    if len(cols_values) != tsv_array.shape[2]:
        raise ValueError("#cols_values={0} unmatched with tsv_array.shape={1}".format(
            len(cols_values), tsv_array.shape
        ))

    df = pd.DataFrame(
        np.reshape(tsv_array, [len(timestamps), -1]),
        columns=["{0}{1}{2}".format(col_symbol, const.SEP, col_value)
                 for col_symbol in cols_symbols for col_value in cols_values],
        index=pd.Series(timestamps, name=const.COL_TIMESTAMP)
    ).reset_index(drop=False)

    if do_augment_cols_time:
        df = dtu.df_add_time_labels(df)

    return df


def tsv2nv(tsv_array):
    """collapse tsv 3dim tensor into nv 2dim array, with #n=#t*#s"""
    if tsv_array is None:
        return None
    assert tsv_array.ndim==3
    return tsv_array.reshape([-1, tsv_array.shape[2]])


def nv2tsv(nv_array, n_symbol):
    """reshape nv 2dim array into tsv 3dim tensor, with #n=#t*#s"""
    if nv_array is None:
        return None
    assert nv_array.ndim==2
    return nv_array.reshape([-1, n_symbol, nv_array.shape[1]])


def xyzwm_tsv2xyzw_nv(x_tsv, y_tsv, z_tsv, w_tsv, mask_tsv):
    x_nv = tsv2nv(x_tsv)
    y_nv = tsv2nv(y_tsv)
    z_nv = tsv2nv(z_tsv)
    w_nv = tsv2nv(w_tsv)
    if mask_tsv is not None:
        idx_valid = mask_tsv.reshape([-1])>0
        x_nv = x_nv[idx_valid,:] if x_nv is not None else None
        y_nv = y_nv[idx_valid,:] if y_nv is not None else None
        z_nv = z_nv[idx_valid,:] if z_nv is not None else None
        w_nv = w_nv[idx_valid,:].reshape([-1]) if w_nv is not None else None
    return x_nv, y_nv, z_nv, w_nv


def tsv2subsymbols_tsv(tsv_array, idx_symbols):
    """sub-index symbol dim to get subset of tsv"""
    if tsv_array is None:
        return None
    assert tsv_array.ndim==3
    if isinstance(idx_symbols, int):
        idx_symbols = [idx_symbols]
    return tsv_array[:,idx_symbols,:]


def fetch_most_recent_files_for_date(dirname, date, list_filename_prefix):
    """(Used for prediction) to get files of the same ending date that are the most recent to the input date.
    NOTE: each filename should be in format prefix*_YYYYMMDD.*

    Args:
        dir_in: the input dirname
        date: YYYYMMDD, the date to be fetched
        list_filename_prefix: list of str, [pref1, pref2, ..., prefk], filename prefix in order
    Returns:
        list_filename: resulted filenames, each basename is pref*_YYYYMMDD.*
    """
    date = dtu.to_date_int(date)
    files = sorted([os.path.join(dirname, f) for f in iom.listdir(dirname)])

    def _find_files(prefix):
        return [f for f in files if f.startswith(os.path.join(dirname, prefix))]

    def _find_file_with_end_date(prefix, date):
        import re
        return [f for f in files if re.findall(r'{}.*_{}\.*'.format(os.path.join(dirname, prefix), date), f)]

    def _get_end_date(filename):
        return dtu.to_date_int(os.path.splitext(os.path.basename(filename))[0].split("_")[-1])

    pref2end_dates = {
        pref: set([_get_end_date(f) for f in _find_files(pref)])
        for pref in list_filename_prefix
    }

    common_end_dates = pref2end_dates[list_filename_prefix[0]]
    for pref in list_filename_prefix[1:]:
        common_end_dates = common_end_dates & pref2end_dates[pref]
    most_recent_end_date = np.max([d for d in common_end_dates if d<date])

    return [
        sorted(_find_file_with_end_date(pref, most_recent_end_date))[-1]
        for pref in list_filename_prefix
    ]


def type_date2df_risk(risk_model, str_type, date):
    """Get dataframe of risks according to different type and date. (Assume the risk models have been built already.)

    Args:
        str_type: str, indicating the type of trisk.
        date: YYYYMMDD
    """
    from stml_mft_china_eq.pyutils.misc_utils import maybe_function_call
    risk_model = maybe_function_call(risk_model)

    if str_type == "trisk":
        assert risk_model.model_code.startswith('PCA')
        return risk_model.date2trisk(date)
    elif str_type == "PCA3_frisk":
        assert risk_model.model_code == 'PCA3'
        return risk_model.date2frisk(date)
    elif str_type == "PCA3_brisk_homo":
        assert risk_model.model_code == 'PCA3'
        return risk_model.date2brisk(date, choice_brisk="homo")
    elif str_type == "PCA3_brisk_heter":
        assert risk_model.model_code == 'PCA3'
        return risk_model.date2brisk(date, choice_brisk="heter")
    elif str_type in ["PCA_frisk", "PCA5_frisk"]:
        assert risk_model.model_code == 'PCA5'
        return risk_model.date2frisk(date)
    elif str_type in ["PCA_brisk_homo", "PCA5_brisk_homo"]:
        assert risk_model.model_code == 'PCA5'
        return risk_model.date2brisk(date, choice_brisk="homo")
    elif str_type in ["PCA_brisk_heter", "PCA5_brisk_heter"]:
        assert risk_model.model_code == 'PCA5'
        return risk_model.date2brisk(date, choice_brisk="heter")
    elif str_type == "SECTORS_frisk":
        assert risk_model.model_code == 'SECTORS'
        return risk_model.date2frisk(date)
    elif str_type == "SECTORS_brisk_homo":
        assert risk_model.model_code == 'SECTORS'
        return risk_model.date2brisk(date, choice_brisk="homo")
    elif str_type == "SECTORS_brisk_heter":
        assert risk_model.model_code == 'SECTORS'
        return risk_model.date2brisk(date, choice_brisk="heter")
    elif str_type == "FA3_frisk":
        assert risk_model.model_code == 'FA3'
        return risk_model.date2frisk(date)
    elif str_type == "FA3_brisk_homo":
        assert risk_model.model_code == 'FA3'
        return risk_model.date2brisk(date, choice_brisk="homo")
    elif str_type == "FA3_brisk_heter":
        assert risk_model.model_code == 'FA3'
        return risk_model.date2brisk(date, choice_brisk="heter")
    elif str_type in ["FA_frisk", "FA5_frisk"]:
        assert risk_model.model_code == 'FA5'
        return risk_model.date2frisk(date)
    elif str_type in ["FA_brisk_homo", "FA5_brisk_homo"]:
        assert risk_model.model_code == 'FA5'
        return risk_model.date2brisk(date, choice_brisk="homo")
    elif str_type in ["FA_brisk_heter", "FA5_brisk_heter"]:
        assert risk_model.model_code == 'FA5'
        return risk_model.date2brisk(date, choice_brisk="heter")
    return NotImplementedError("str_type={} not supported".format(str_type))


def model_eval_parse_yhat_expression(expr):
    list_weight_names = []
    for item in expr.split("+"):
        sub_items = item.split("*")
        assert len(sub_items) == 2
        _wt = float(sub_items[0].strip())
        _name = sub_items[1].strip()
        list_weight_names.append((_wt, _name))
    return list_weight_names


def timing(func):
    import time
    from functools import wraps

    @wraps(func)
    def wrap(self, *args, **kwargs):
        start = time.time()
        try:
            v = func(self, *args, **kwargs)
            return v
        finally:
            end = time.time()
            logging.info("{} takes {} ms".format(self.dir_data, (end - start) * 1000))
    return wrap
