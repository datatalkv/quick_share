import torch
from torch import nn
from typing import Any, Callable, ClassVar, List, Set, Dict, Union, Optional, Tuple


class BucketEmb(nn.Module):
    def __init__(self, n_in: int, n_hidden: int = 16, boundaries: Optional[torch.Tensor] = None):
        """Basic bucketize and embedding layer.

        Args:
            n_in: int, the dim of input features, i.e., input will be (n_sample, n_in)
            n_hidden: int, the dim of output of this layer, i.e., the dim of embedding
            boundaries: torch.Tensor, the boundary to do the bucketization for EACH dimension out of n_in
        """
        super(BucketEmb, self).__init__()
        if boundaries is None:
            boundaries = torch.tensor([-3, -2, 2, 3])
        self.boundaries = nn.Parameter(boundaries, requires_grad=False)
        self.n_in = n_in
        self.n_hidden = n_hidden
        self.list_emb = nn.ModuleList([
            nn.Embedding(len(self.boundaries)+1, self.n_hidden)
            for _ in range(self.n_in)
        ])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        assert x.shape[1] == self.n_in
        digit_x = torch.bucketize(x, self.boundaries)
        # h.shape = (n_samp, n_hidden, n_in)
        h = torch.cat([
            torch.unsqueeze(self.list_emb[i](digit_x[:, i]), 2)
            for i in range(self.n_in)
        ], 2)
        return torch.mean(h, 2)

    def L2norm(self):
        return torch.mean(torch.stack([torch.mean(emb.weight**2) for emb in self.list_emb]))

    @property
    def l_aux(self):
        return self.L2norm()


class LinearWithBucketEmb(nn.Module):
    def __init__(self, n_in: int, n_hidden: int = 16, bias: bool = False, boundaries: Optional[torch.Tensor] = None):
        super(LinearWithBucketEmb, self).__init__()
        self.linear_part = nn.Linear(n_in, n_hidden, bias=bias)
        self.bucket_part = BucketEmb(n_in, n_hidden=n_hidden, boundaries=boundaries)

    def forward(self, x):
        return self.linear_part(x) + self.bucket_part(x)

    def emb_L2norm(self):
        return self.bucket_part.L2norm()

    @property
    def l_aux(self):
        return self.emb_L2norm()


class BottleBlock(nn.Module):
    def __init__(self, n_in: int, n_hidden: int = 16, activation = nn.Mish(), dropout = nn.Identity(), shortcut = nn.Identity(), bias: bool = True, do_batchnorm: bool = False):
        """Basic bottlenet block.

        Args:
            n_in: int, the dim of input features, i.e., input will be (n_sample, n_in)
            n_hidden: int, the dim of inner bottlenet
            activation: activation on the bottle inner
            dropout: dropout function on the residual
            shortcut: the shortcut function
            bias: for linear mapping
            do_batchnorm: whether use batchnorm before activation
        """
        super(BottleBlock, self).__init__()
        self.n_in = n_in
        self.n_hidden = n_hidden
        self.activation = activation
        self.dropout = dropout
        self.shortcut = shortcut
        self.bias = bias
        layers = [nn.Linear(n_in, n_hidden, bias=self.bias)]
        if do_batchnorm:
            layers.append(nn.BatchNorm1d(n_hidden))
        layers += [
            self.activation,
            nn.Linear(n_hidden, n_in, bias=self.bias),
            self.dropout
        ]
        self.layers = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """output is of the same size as input!"""
        assert x.shape[1] == self.n_in
        return self.layers(x) + self.shortcut(x)

    @property
    def l_aux(self):
        return 0.0
