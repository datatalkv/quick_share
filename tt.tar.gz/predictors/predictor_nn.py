# -*- coding: utf-8 -*-
"""
NN predictors
"""
import logging
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.distributions.normal import Normal
from typing import Any, Callable, ClassVar, List, Set, Dict, Union, Optional, Tuple


from stml_mft_china_eq.pyutils.tqdmX import TqdmWrapper, format_str
from stml_mft_china_eq.statarb.gym.predictors import loss_nn
from stml_mft_china_eq.statarb.gym.predictors import layer_nn
from stml_mft_china_eq.statarb.gym.predictors import utils_nn



class BaseNet(nn.Module):
    def __init__(self, *args, **kwargs):
        super(BaseNet, self).__init__()

    @property
    def device(self):
        return list(self.parameters())[0].device

    def forward(self, x, **kwargs):
        return self.layers(x)

    def predict(self, input_x):
        _device = self.device
        if isinstance(input_x, np.ndarray):
            x = torch.from_numpy(input_x).float().to(_device)
        else:
            x = input_x.to(_device)
        yhat = self.forward(x)
        return yhat.detach().to("cpu").numpy()

    def score(self, input_x, y):
        """R2 as the score, to align with sklearn"""
        from sklearn.metrics import r2_score
        yhat = self.predict(input_x)
        return r2_score(y, yhat)

    @property
    def str_name(self) :
        return "BaseNet"


class MLP(BaseNet):
    def __init__(self, n_in: int, n_out: int, n_hiddens: Union[List, Tuple] = (256, 128, 3), bias: bool = False, activation: str = "mish", dropout: Optional[float] = 0.5, use_bucket_emb: bool = False):
        """Basic MLP structure.

        Args:
            n_in: int, the dim of input features, i.e., input will be (n_sample, n_in)
            n_out: int, the dim of output, i.e., out will be (n_sample, n_out)
            n_hiddens: list or tuple, the dim of hidden layers in sequential order
            bias: bool, whether each fc linear layer includes bias terms
            activation: str, indicating the nonlinear activation layer
            dropout: None or 0~1 float
            use_bucket_emb: bool, whether use layer_nn.BucketEmb at the bottom layer
        """
        super(MLP, self).__init__()
        self._str_activation = activation.lower()
        if self._str_activation == "relu":
            self.activation = nn.ReLU()
        elif self._str_activation == "tanh":
            self.activation = nn.Tanh()
        elif self._str_activation == "softsign":
            self.activation = nn.Softsign()
        elif self._str_activation == "mish":
            self.activation = nn.Mish()
        else:
            raise NotImplementedError(f"Unsupported activation = {activation}")

        self._str_dropout = str(dropout) if dropout else "0"
        self.dropout = nn.Dropout(dropout) if dropout else nn.Identity()

        self.use_bucket_emb = use_bucket_emb
        self.bias = bias
        self.n_hiddens = n_hiddens
        if self.use_bucket_emb:
            list_layers = [layer_nn.LinearWithBucketEmb(n_in, n_hidden=n_hiddens[0], bias=self.bias), self.activation]
        else:
            list_layers = [nn.Linear(n_in, n_hiddens[0], bias=self.bias), self.activation]

        for i_hidden in range(1, len(n_hiddens)):
            list_layers.extend([
                nn.Linear(n_hiddens[i_hidden-1], n_hiddens[i_hidden], bias=self.bias),
                self.activation,
                self.dropout
            ])
        list_layers.append(nn.Linear(n_hiddens[-1], n_out, bias=self.bias))
        self.layers = nn.Sequential(*list_layers)

    def emb_L2norm(self):
        if self.use_bucket_emb:
            return self.layers[0].emb_L2norm()
        else:
            return 0.0

    @property
    def l_aux(self):
        if self.use_bucket_emb:
            return self.layers[0].l_aux
        else:
            return 0.0

    @property
    def str_n_hiddens(self):
        return "#".join(["hidden"] + [str(_) for _ in self.n_hiddens])

    @property
    def str_activation(self):
        return "act#" + self._str_activation

    @property
    def str_use_bucket_emb(self):
        return "bucket#" + str(int(self.use_bucket_emb))

    @property
    def str_bias(self):
        return "bias#" + str(int(self.bias))

    @property
    def str_dropout(self):
        return "drop#" + self._str_dropout

    @property
    def str_name(self) :
        _str_name = "|".join(["MLP", self.str_n_hiddens, self.str_use_bucket_emb, self.str_bias, self.str_activation, self.str_dropout])
        return _str_name


class BottleStack(BaseNet):
    def __init__(self, n_in: int, n_out: int, n_hiddens: Union[List, Tuple] = (256, 128, 3), bias: bool = False, activation: str = "mish", dropout: Optional[float] = 0.5, use_bucket_emb: bool = False):
        """Basic BottleStack structure.

        Args:
            n_in: int, the dim of input features, i.e., input will be (n_sample, n_in)
            n_out: int, the dim of output, i.e., out will be (n_sample, n_out)
            n_hiddens: list or tuple, the dim of hidden layers in sequential order
            bias: bool, whether each fc linear layer includes bias terms
            activation: str, indicating the nonlinear activation layer
            dropout: None or 0~1 float
            use_bucket_emb: bool, whether use layer_nn.BucketEmb at the bottom layer
        """
        super(BottleStack, self).__init__()
        self._str_activation = activation.lower()
        if self._str_activation == "relu":
            self.activation = nn.ReLU()
        elif self._str_activation == "tanh":
            self.activation = nn.Tanh()
        elif self._str_activation == "softsign":
            self.activation = nn.Softsign()
        elif self._str_activation == "mish":
            self.activation = nn.Mish()
        else:
            raise NotImplementedError(f"Unsupported activation = {activation}")

        self._str_dropout = str(dropout) if dropout else "0"
        self.dropout = nn.Dropout(dropout) if dropout else nn.Identity()

        self.use_bucket_emb = use_bucket_emb
        self.bias = bias
        self.n_hiddens = n_hiddens
        self.shortcut = nn.Identity()
        if self.use_bucket_emb:
            list_layers = [layer_nn.LinearWithBucketEmb(n_in, n_hidden=n_hiddens[0], bias=self.bias), self.activation]
        else:
            list_layers = [nn.Linear(n_in, n_hiddens[0], bias=self.bias), self.activation]

        for i_hidden in range(1, len(n_hiddens)):
            list_layers.append(layer_nn.BottleBlock(
                n_in=n_hiddens[0],
                n_hidden=n_hiddens[i_hidden],
                activation=self.activation,
                bias=self.bias,
                do_batchnorm=True,
                dropout=self.dropout
            ))
        list_layers.append(nn.Linear(n_hiddens[0], n_out, bias=self.bias))
        self.layers = nn.Sequential(*list_layers)

    def emb_L2norm(self):
        if self.use_bucket_emb:
            return self.layers[0].emb_L2norm()
        else:
            return 0.0

    @property
    def l_aux(self):
        if self.use_bucket_emb:
            return self.layers[0].l_aux
        else:
            return 0.0

    @property
    def str_n_hiddens(self):
        return "#".join(["hidden"] + [str(_) for _ in self.n_hiddens])

    @property
    def str_activation(self):
        return "act#" + self._str_activation

    @property
    def str_use_bucket_emb(self):
        return "bucket#" + str(int(self.use_bucket_emb))

    @property
    def str_bias(self):
        return "bias#" + str(int(self.bias))

    @property
    def str_dropout(self):
        return "drop#" + self._str_dropout

    @property
    def str_name(self) :
        _str_name = "|".join(["BotStack", self.str_n_hiddens, self.str_use_bucket_emb, self.str_bias, self.str_activation, self.str_dropout])
        return _str_name


class MoE(BaseNet):
    """Call a Sparsely gated mixture of experts layer with 1-layer Feed-Forward networks as experts.
    """
    # def __init__(self, n_in, n_experts, expert_module=None, noisy_gating=True, k=4, **kwargs_per_expert):
    def __init__(self, n_in, n_experts, expert_module=None, noisy_gating=True, k=4, kwargs_per_expert={}):
        """Basic MoE structure.

        Args:
            n_in: integer - size of the input
            n_experts: integer, number of experts
            noisy_gating: boolean
            k: integer - how many experts to use for each batch element
        """
        super(MoE, self).__init__()
        self.noisy_gating = noisy_gating
        self.n_experts = n_experts
        self.n_in = n_in
        self.k = k
        # instantiate experts
        if expert_module is None:
            expert_module = MLP
            kwargs_per_expert = {
                "n_in": self.n_in,
                "n_out": 1,
                "n_hiddens": [10, 5],
            }
        self.experts = nn.ModuleList([
            expert_module(**kwargs_per_expert)
            for _ in range(self.n_experts)
        ])
        self.w_gate = nn.Parameter(torch.zeros(n_in, n_experts), requires_grad=True)
        self.w_noise = nn.Parameter(torch.zeros(n_in, n_experts), requires_grad=True)

        self.softplus = nn.Softplus()
        self.softmax = nn.Softmax(1)
        self.normal = Normal(torch.tensor([0.0]).to(self.device), torch.tensor([1.0]).to(self.device))
        assert(self.k <= self.n_experts)

    @property
    def str_n_experts(self):
        return "experts#{}".format(self.n_experts)

    @property
    def str_noisy_gating(self):
        return "noisegate#" + str(int(self.noisy_gating))

    @property
    def str_each_expert(self):
        return self.experts[0].str_name

    @property
    def str_name(self) :
        _str_name = "|".join(["MoE", self.str_n_experts, self.str_noisy_gating, self.str_each_expert])
        return _str_name

    def emb_L2norm(self):
        if hasattr(self.experts[0], "use_bucket_emb"):
            if self.experts[0].use_bucket_emb:
                return torch.mean(torch.stack([
                    ee.emb_L2norm() for ee in self.experts
                ]))
        return 0.0

    @property
    def l_aux(self):
        if hasattr(self.experts[0], "use_bucket_emb"):
            if self.experts[0].use_bucket_emb:
                return torch.mean(torch.stack([
                    ee.l_aux for ee in self.experts
                ]))
        return 0.0

    def cv_squared(self, x):
        """The squared coefficient of variation of a sample.
        Useful as a loss to encourage the routing to be more uniform.
        Epsilons added for numerical stability.

        Args:
            x: a `Tensor`.
        Returns:
            `Scalar`. Return 0 for an empty Tensor.
        """
        eps = 1e-10
        # if only n_experts = 1
        if x.shape[0] == 1:
            return torch.Tensor([0]).to(self.device)
        return x.float().var() / (x.float().mean()**2 + eps)


    def _gates_to_load(self, gates):
        """Compute the true load per expert, given the gates.
        The load is the number of examples for which the corresponding gate is >0.

        Args:
            gates: a `Tensor` of shape [batch_size, n]
        Returns:
            a float32 `Tensor` of shape [n]
        """
        return (gates > 0).sum(0)

    def _prob_in_top_k(self, clean_values, noisy_values, noise_stddev, noisy_top_values):
        """Computes the probability that value is in top k, given different random noise.
        This gives us a way of backpropagating from a loss that balances the number
        of times each expert is in the top k experts per example.
        In the case of no noise, pass in None for noise_stddev, and the result will
        not be differentiable.

        Args:
            clean_values: a `Tensor` of shape [batch, n].
            noisy_values: a `Tensor` of shape [batch, n].  Equal to clean values plus
                normally distributed noise with standard deviation noise_stddev.
            noise_stddev: a `Tensor` of shape [batch, n], or None
            noisy_top_values: a `Tensor` of shape [batch, m].
           "values" Output of tf.top_k(noisy_top_values, m).  m >= k+1
        Returns:
            a `Tensor` of shape [batch, n].
        """
        batch = clean_values.size(0)
        m = noisy_top_values.size(1)
        top_values_flat = noisy_top_values.flatten()

        threshold_positions_if_in = torch.arange(batch).to(self.device) * m + self.k
        threshold_if_in = torch.unsqueeze(torch.gather(top_values_flat, 0, threshold_positions_if_in), 1)
        is_in = torch.gt(noisy_values, threshold_if_in)
        threshold_positions_if_out = threshold_positions_if_in - 1
        threshold_if_out = torch.unsqueeze(torch.gather(top_values_flat,0 , threshold_positions_if_out), 1)
        # is each value currently in the top k.
        if self.normal.mean.device != self.device:
            self.normal = Normal(torch.tensor([0.0]).to(self.device), torch.tensor([1.0]).to(self.device))
        prob_if_in = self.normal.cdf((clean_values - threshold_if_in)/noise_stddev)
        prob_if_out = self.normal.cdf((clean_values - threshold_if_out)/noise_stddev)
        prob = torch.where(is_in, prob_if_in, prob_if_out)
        return prob

    def noisy_top_k_gating(self, x, train, noise_epsilon=1e-2):
        """Noisy top-k gating. See paper: https://arxiv.org/abs/1701.06538.

        Args:
            x: input Tensor with shape [batch_size, n_in]
            train: a boolean - we only add noise at training time.
            noise_epsilon: a float
        Returns:
            gates: a Tensor with shape [batch_size, n_experts]
            load: a Tensor with shape [n_experts]
        """
        clean_logits = x @ self.w_gate
        if self.noisy_gating and train:
            raw_noise_stddev = x @ self.w_noise
            noise_stddev = ((self.softplus(raw_noise_stddev) + noise_epsilon))
            noisy_logits = clean_logits + ( torch.randn_like(clean_logits).to(self.device) * noise_stddev)
            logits = noisy_logits
        else:
            logits = clean_logits

        # calculate topk + 1 that will be needed for the noisy gates
        top_logits, top_indices = logits.topk(min(self.k + 1, self.n_experts), dim=1)
        top_k_logits = top_logits[:, :self.k]
        top_k_indices = top_indices[:, :self.k]
        top_k_gates = self.softmax(top_k_logits)

        zeros = torch.zeros_like(logits, requires_grad=True).to(self.device)
        gates = zeros.scatter(1, top_k_indices, top_k_gates).to(self.device)

        if self.noisy_gating and self.k < self.n_experts and train:
            load = (self._prob_in_top_k(clean_logits, noisy_logits, noise_stddev, top_logits)).sum(0)
        else:
            load = self._gates_to_load(gates)
        return gates, load

    def forward(self, x, with_aux_loss=False):
        """
        Args:
            x: tensor shape [batch_size, n_in]
            with_aux_loss: bool

        Returns:
            y: a tensor with shape [batch_size, n_out].
            aux_loss: scalar if with_aux_loss. This should be added into the overall loss with weight.
                Minimizing this loss encourages all experts to be uniformly routed.
        """
        gates, load = self.noisy_top_k_gating(x, self.training)
        # calculate importance loss
        importance = gates.sum(0)
        # cv_squared loss
        aux_loss = self.cv_squared(importance) + self.cv_squared(load)

        dispatcher = utils_nn.SparseDispatcher(self.n_experts, gates, device=self.device)
        expert_inputs = dispatcher.dispatch(x)
        gates = dispatcher.expert_to_gates()
        expert_outputs = [self.experts[i](expert_inputs[i]) for i in range(self.n_experts)]
        # for i in range(self.n_experts):
        #     print(i, expert_inputs[i].shape, expert_outputs[i].shape, "*"*(10*(expert_outputs[i].shape[0]==0)))
        y = dispatcher.combine(expert_outputs)

        if with_aux_loss:
            return y, aux_loss
        else:
            return y
