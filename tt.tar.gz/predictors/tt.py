from stml_mft_china_eq.statarb.gym import predictors

if __name__ == "__main__":
    # quick demo and test usage
    import numpy as np
    n_sample = 1000
    X = np.random.randn(n_sample, 5)
    y = np.random.randn(n_sample)
    intervals = np.random.choice(1440, n_sample)

    m1 = predictors.make_predictor("ridge", **predictors.get_default_kwargs("ridge"))
    m1.fit(X, y)
    m2 = predictors.make_predictor("lgb", **predictors.get_default_kwargs("lgb"))
    m2.fit(X, y)
    m3 = predictors.make_predictor("todmoewtridge", **predictors.get_default_kwargs("todmoewtridge"))
    m3.fit(X, intervals, y)
    m4 = predictors.make_predictor("todmoelgb", **predictors.get_default_kwargs("todmoelgb"))
    m4.fit(X, intervals, y)


    yhat1 = m1.predict(X)
    yhat2 = m2.predict(X)
    yhat3 = m3.predict(X, intervals)
    yhat4 = m4.predict(X, intervals)

    cont_mat = np.concatenate([
        y.reshape([1,-1]),
        yhat1.reshape([1,-1]),
        yhat2.reshape([1,-1]),
        yhat3.reshape([1,-1]),
        yhat4.reshape([1,-1]),
    ], 0)

    print("corrcoef:")
    print(np.corrcoef(cont_mat))
    print("sqrt(E[x^2]):")
    print(np.sqrt(np.mean(cont_mat**2, 1)))
    print("E[x]/sqrt(E[x^2]):")
    print(np.mean(cont_mat, 1) / np.sqrt(np.mean(cont_mat**2, 1)))
