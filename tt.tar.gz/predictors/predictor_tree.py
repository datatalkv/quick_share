# -*- coding: utf-8 -*-
"""
Tree predictors
"""
import logging
import numpy as np
import xgboost as xgb
import lightgbm as lgb
from sklearn.ensemble import RandomForestRegressor

#TODO: efficiency of xgb
class XGBRegressor(xgb.XGBRegressor):
    def __init__(self, max_depth=3, learning_rate=0.1, n_estimators=100,
                 silent=True, objective="reg:linear", booster='gbtree',
                 n_jobs=1, nthread=None, gamma=0, min_child_weight=1, max_delta_step=0,
                 subsample=1, colsample_bytree=1, colsample_bylevel=1,
                 reg_alpha=0, reg_lambda=1, scale_pos_weight=1,
                 base_score=0.5, random_state=0, seed=None, missing=None, **kwargs):
        self.max_depth = max_depth
        self.learning_rate = learning_rate
        self.n_estimators = n_estimators
        self.silent = silent
        self.objective = objective
        self.booster = booster
        self.gamma = gamma
        self.min_child_weight = min_child_weight
        self.max_delta_step = max_delta_step
        self.subsample = subsample
        self.colsample_bytree = colsample_bytree
        self.colsample_bylevel = colsample_bylevel
        self.reg_alpha = reg_alpha
        self.reg_lambda = reg_lambda
        self.scale_pos_weight = scale_pos_weight
        self.base_score = base_score
        self.missing = missing if missing is not None else np.nan
        self.kwargs = kwargs
        self._Booster = None
        self.seed = seed
        self.random_state = random_state
        self.nthread = nthread
        self.n_jobs = n_jobs

    def fit(self, X, y, bool_demean=True, bool_flip_aug=True, sample_weight=None, **kwargs):
        if bool_demean:
            y = y - np.mean(y)
        if bool_flip_aug:
            X = np.concatenate([X, -X], 0)
            y = np.concatenate([y, -y], 0)
            if sample_weight is not None:
                sample_weight = np.concatenate([sample_weight] * 2, 0)
        self = super(XGBRegressor, self).fit(X, y, sample_weight=sample_weight, **kwargs)
        return self


class LGBRegressor(lgb.LGBMRegressor):
    def fit(self, X, y, bool_demean=True, bool_flip_aug=True, sample_weight=None, **kwargs):
        if bool_demean:
            y = y - np.mean(y)
        if bool_flip_aug:
            X = np.concatenate([X, -X], 0)
            y = np.concatenate([y, -y], 0)
            if sample_weight is not None:
                sample_weight = np.concatenate([sample_weight] * 2, 0)
        self = super(LGBRegressor, self).fit(X, y, sample_weight=sample_weight, **kwargs)
        return self


#TODO: efficiency of RF
class RFRegressor(RandomForestRegressor):
    def fit(self, X, y, bool_demean=True, bool_flip_aug=True, sample_weight=None, **kwargs):
        if bool_demean:
            y = y - np.mean(y)
        if bool_flip_aug:
            X = np.concatenate([X, -X], 0)
            y = np.concatenate([y, -y], 0)
            if sample_weight is not None:
                sample_weight = np.concatenate([sample_weight] * 2, 0)
        self = super(RFRegressor, self).fit(X, np.ravel(y), sample_weight=sample_weight, **kwargs)
        return self


if __name__ == "__main__":
    import pandas as pd
    pd.options.display.float_format = '{:.4f}'.format

    n_samp = 10000
    d_x = 10

    x = np.random.randn(n_samp, d_x) + 10 * np.random.randn(1, d_x)
    x_pseudo = np.random.randn(n_samp, d_x) * 10
    y = np.random.randn(n_samp) + 10 * np.random.randn()

    # for model in [xgb.XGBRegressor, lgb.LGBMRegressor, RandomForestRegressor, XGBRegressor, LGBRegressor, RFRegressor]:
    for model in [XGBRegressor, LGBRegressor, RFRegressor]:
        m = model()
        m.fit(x, y, bool_demean=False, bool_flip_aug=False)
        yhat_ff = m.predict(x)
        yhat_pseudo_ff = m.predict(x_pseudo)

        m = model()
        m.fit(x, y, bool_demean=True, bool_flip_aug=False)
        yhat_tf = m.predict(x)
        yhat_pseudo_tf = m.predict(x_pseudo)

        m = model()
        m.fit(x, y, bool_demean=False, bool_flip_aug=True)
        yhat_ft = m.predict(x)
        yhat_pseudo_ft = m.predict(x_pseudo)

        m = model()
        m.fit(x, y, bool_demean=True, bool_flip_aug=True)
        yhat_tt = m.predict(x)
        yhat_pseudo_tt = m.predict(x_pseudo)

        df_yhat = pd.DataFrame(
            np.concatenate([
                y.reshape([-1,1]),
                yhat_ff.reshape([-1,1]),
                yhat_pseudo_ff.reshape([-1,1]),
                yhat_tf.reshape([-1,1]),
                yhat_pseudo_tf.reshape([-1,1]),
                yhat_ft.reshape([-1,1]),
                yhat_pseudo_ft.reshape([-1,1]),
                yhat_tt.reshape([-1,1]),
                yhat_pseudo_tt.reshape([-1,1]),
            ], 1),
            columns=["y",
                     "NDNF", "NDNFp",
                     "YDNF", "YDNFp",
                     "NDYF", "NDYFp",
                     "YDYF", "YDYFp"
                     ]
        )
        print(df_yhat[[c for c in df_yhat.columns if not c.endswith("p")]].corr())
        df_mean = df_yhat.mean()
        df_mean.name = "mean"
        df_std = df_yhat.std()
        df_std.name = "std"
        df_Ex2 = df_mean**2 + df_std**2
        df_Ex2.name = "E[x**2]"
        print(pd.concat([df_mean.to_frame(), df_std.to_frame(), df_Ex2.to_frame()], 1))
    import IPython; IPython.embed(); sys.exit(0)
