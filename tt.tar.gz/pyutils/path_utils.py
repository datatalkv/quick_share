import tempfile

def tmp_context(prefix: Optional[str] = None, suffix: Optional[str] = None) -> tempfile.TemporaryDirectory:
    return tempfile.TemporaryDirectory(prefix=prefix, suffix=suffix)
