import os
import sys
import copy
import contextlib
from contextlib import contextmanager
import itertools
import inspect
from collections import OrderedDict
import numpy as np
import torch
import logging
import types
from typing import Any, Callable, ClassVar, List, Dict, Union, Optional


def import_module(module: str) -> types.ModuleType:
    module_ = __import__(module, fromlist=[""])
    # module_ = __import__(module)
    return module_


def import_object(module: str, object: str) -> Union[types.MethodType, types.ModuleType]:
    module_ = import_module(module)
    obj = getattr(module_, object)
    return obj


def function_call(module: str, func: str, *args, **kwargs):
    """Call a function in a module."""
    func_ = import_object(module, func)
    try:
        res = func_(*args, **kwargs)
    except Exception as e:
        msg = "function_call: {}.{}".format(module, func)
        args_info = "(" + ", ".join([repr(x) for x in args])
        if kwargs:
            args_info += ", " if args else ""
            args_info += ", ".join(["%s=%s" % (k, repr(v)) for k, v in kwargs.items()])
        args_info += ")"
        if len(args_info.__repr__()) > 5000:
            args_info = "<args truncated due to excessive length>"
        msg += args_info

        raise ValueError(f"Exception: {e}\n\tMessage: {msg}")

    return res


def maybe_function_call(x: Union[Dict, Callable]):
    if isinstance(x, dict) and "module" in x and "func" in x:
        x = function_call(**x)
    return x


def partial_function_call(module: str, func: str, *args, **kwargs):
    from functools import partial
    func_ = import_object(module, func)
    res = partial(func_, *args, **kwargs)
    return res


def maybe_partial_function_call(x: Union[Dict, Callable]):
    if isinstance(x, dict) and "module" in x and "func" in x:
        x = partial_function_call(**x)
    return x


@contextlib.contextmanager
def set_random_seed(seed: int):
    import random
    orig_seed = random.getstate()
    try:
        random.seed(seed)
        yield
    finally:
        random.setstate(orig_seed)


@contextlib.contextmanager
def set_numpy_random_seed(seed: int):
    orig_seed = np.random.get_state()
    try:
        np.random.seed(seed)
        yield
    finally:
        np.random.set_state(orig_seed)


def seed_all(seed: int):
    """Seed all: random, np, torch, cuda, etc."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed_value)
        torch.cuda.manual_seed_all(seed_value)      # gpu vars
        torch.backends.cudnn.deterministic = True   # needed
        torch.backends.cudnn.benchmark = False


def is_cartesian_expandable(key: str) -> bool:
    return key.startswith("*")


def expand_params(params: Dict) -> List[Dict]:
    new_params = {}
    for key, val in params.items():
        if not is_cartesian_expandable(key):
            new_params[key] = [val]
        else:
            new_params[key[1:]] = val
    new_params = OrderedDict(sorted(new_params.items()))
    all_params_list = itertools.product(*new_params.values)
    keys = new_params.keys()
    all_params = [{key: val for key, val in zip(keys, p)} for p in all_params_list]
    return all_params

def expand_params_recursive(params: Dict) -> List[Dict]:
    new_params = {}
    for key, val in params.items():
        if not is_cartesian_expandable(key):
            if isinstance(val, dict):
                new_params[key] = expand_params_recursive(val)
            else:
                new_params[key] = [val]
        else:
            new_params[key[1:]] = val

    new_params = OrderedDict(sorted(new_params.items()))
    all_params_list = itertools.product(*new_params.values())
    keys = new_params.keys()
    all_params = [{key: val for key, val in zip(keys, p)} for p in all_params_list]
    return all_params

def coerce_to_list(x) -> List:
    if x:
        if not isinstance(x, list):
            x = list(x)
        return x
    else:
        return []


def get_gpu_device(n_try: int = 3, order: str = "memory", limit=1, maxLoad=0.4, maxMemory=0.4, **kwargs) -> Optional[int]:
    """Get the id of GPU device"""
    import GPUtil
    import time
    if torch.cuda.is_available():
        assert order in ["random", "memory", "load"]
        for _ in range(n_try):
            try:
                list_id_gpu = GPUtil.getAvailable(order=order, limit=limit, maxLoad=maxLoad, maxMemory=maxMemory)
                if len(list_id_gpu) == 0:
                    # No free GPUs available, just wait
                    time.sleep(30)
                    continue
                else:
                    return list_id_gpu[0]
            except Exception as e:
                return None

    return None
