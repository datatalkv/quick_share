import time
import functools
from contextlib import ContextDecorator
from dataclasses import dataclass, field
from typing import Any, Callable, ClassVar, Dict, Optional

from stml_mft_china_eq.pyutils.custom_logger import CustomLogger


class TimerError(Exception):
    """A custom exception used to report errors in use of Timer class"""

@dataclass
class Timer(ContextDecorator):
    """Time your script in either a class, a context manager, or a decorator way"""

    timers: ClassVar[Dict[str, float]] = {}
    name: Optional[str] = None
    text: str = "Elapsed time: {:0.4f} seconds"
    logger: Optional[Callable[[str], None]] = print
    _start_time: Optional[float] = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        """Initialization: add timer to dict of timers"""
        if self.name:
            self.timers.setdefault(self.name, 0)

    def start(self) -> None:
        """Start a new timer, raise error if there is something running.
        See .tic for a different strategy.
        """
        if self._start_time is not None:
            raise TimerError(f"Timer is still running. Use .stop() to stop it")
        self._start_time = time.perf_counter()

    def stop(self) -> float:
        """Stop the timer, and report the elapsed time.
        See .toc for a different strategy.
        """
        if self._start_time is None:
            raise TimerError(f"Timer is not running. Use .start() or .tic() to start it")
        # Calculate the elapsed time
        elapsed_time = time.perf_counter() - self._start_time
        self._start_time = None
        # Report the elapsed time
        if self.logger:
            self.logger(self.text.format(elapsed_time))
        if self.name:
            self.timers[self.name] = self.timers[self.name] + elapsed_time
        return elapsed_time

    def tic(self) -> None:
        """Reset the start_time without caring about whether it's running.
        See .start for a different strategy.
        """
        self._start_time = time.perf_counter()

    def toc(self) -> float:
        """Return elapsed time by .stop(), and run .start() imediately for the next toc() call.
        See .stop for a different strategy.
        """
        elapsed_time = self.stop()
        self.tic()
        return elapsed_time

    def total(self) -> float:
        """Return the acuumulated elapsed_time"""
        if self.name:
            return self.timers[self.name]
        else:
            return .0

    def __enter__(self) -> "Timer":
        """Start a new timer as a context manager"""
        self.start()
        return self

    def __exit__(self, *exc_info: Any) -> None:
        """Stop the context manager timer"""
        self.stop()

    def __call__(self, func):
        """Support using Timer as a decorator"""
        @functools.wraps(func)
        def wrapper_timer(*args, **kwargs):
            with self:
                return func(*args, **kwargs)

        return wrapper_timer

