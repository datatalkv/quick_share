import os
import sys
import logging
import datetime
from inspect import getframeinfo, stack
from typing import Any, Callable, ClassVar, List, Dict, Union, Optional


class CallerFilter(logging.Filter):
    """ This class adds some context to the log record instance """
    file = ''
    line_n = ''

    def filter(self, record) -> bool:
        record.file = self.file
        record.line_n = self.line_n
        return True


def caller_reader(f):
    """This wrapper updates the context with the caller info"""
    def wrapper(self, *args):
        caller = getframeinfo(stack()[1][0])
        self._filter.file = caller.filename
        self._filter.line_n = caller.lineno
        return f(self, *args)
    return wrapper


class CustomFormatter(logging.Formatter):
    """Logging colored formatter, adapted from https://stackoverflow.com/a/56944256/3638629"""

    grey = '\x1b[38;21m'
    blue = '\x1b[38;5;39m'
    yellow = '\x1b[38;5;226m'
    red = '\x1b[38;5;196m'
    bold_red = '\x1b[31;1m'
    reset = '\x1b[0m'

    def __init__(self, fmt: str):
        super().__init__()
        self.fmt = fmt
        self.FORMATS = {
            logging.DEBUG: self.grey + self.fmt + self.reset,
            logging.INFO: self.blue + self.fmt + self.reset,
            logging.WARNING: self.yellow + self.fmt + self.reset,
            logging.ERROR: self.red + self.fmt + self.reset,
            logging.CRITICAL: self.bold_red + self.fmt + self.reset,
        }

    def format(self, record: Any):
        log_fmt = self.FORMATS.get(record.levelno)
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)


class CustomLogger(logging.getLoggerClass()):
    def __init__(self, name: str, verbose: bool = True, log_dir: Optional[str] = None, logging_level: str = "debug"):
        """Create a custom logger with the specified `name`. When `log_dir` is None, a simple
        console logger is created. Otherwise, a file logger is created in addition to the console
        logger.

        Args:
            name: str, name of the logger, will display in the message
            verbose: bool (optional), whether the logging should be verbose. Default=True.
                if True, all messages get logged both to stdout and to the log file (if `log_dir` is specified);
                if False, messages will ignore terminal and get logged to the log file (if `log_dir` is specified)
            log_dir: str (optional), the directory for the log file; if None, no log file is created
            logging_level: str (optional), the logging level, default='debug'
        """
        # Create custom logger logging all five levels
        super().__init__(name)
        # self.str_fmt = '[%(levelname)s] %(asctime)s | %(name)s | %(filename)s:%(lineno)d | %(message)s'
        self.str_fmt = '[%(levelname)s] %(asctime)s | %(name)s:%(file)s:%(line_n)s | %(message)s'
        self.formatter_color = CustomFormatter(self.str_fmt)
        self.formatter_plain = logging.Formatter(self.str_fmt)

        # logging level string to object
        self.logging_level = {
            "debug": logging.DEBUG,
            "info" : logging.INFO,
            "warn": logging.WARNING,
            "warning": logging.WARNING,
            "error": logging.ERROR,
            "critical": logging.CRITICAL,
        }[logging_level.lower()]
        self.setLevel(self.logging_level)

        # Determine verbosity settings
        self.verbose = verbose

        # Create stream handler for logging to stdout (log all five levels)
        self.stdout_handler = logging.StreamHandler(sys.stdout)
        self.stdout_handler.setLevel(self.logging_level)
        self.stdout_handler.setFormatter(self.formatter_color)
        self.enable_console_output()

        # Create file handler
        if log_dir is not None:
            self.add_file_handler(log_dir)

        # Create filter to trace the function and line the call comes from
        self._filter = CallerFilter()
        self.addFilter(self._filter)


    def add_file_handler(self, log_dir: str) -> None:
        """Add a file handler for this logger with the specified self.name and time signature,
        (and store the log file under `log_dir`).
        """
        # Determine log path and file name; create log path if it does not exist
        log_name = '{0}_{1}'.format(
            str(self.name).replace(" ", "_"),
            datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        )
        if not os.path.exists(log_dir):
            try:
                os.makedirs(log_dir)
            except Exception as e:
                print(f'Exception: {e}')
                print(f'{self.__class__.__name__}: Cannot create directory {log_dir}. ', end='', file=sys.stderr)
                log_dir = '/tmp' if sys.platform.startswith('linux') else '.'
                print(f'Defaulting to {log_dir}.', file=sys.stderr)

        log_filename = os.path.join(log_dir, log_name + '.log')

        # Create file handler for logging to a file
        self.file_handler = logging.FileHandler(log_filename)
        self.file_handler.setLevel(self.logging_level)
        self.file_handler.setFormatter(self.formatter_plain)
        self.addHandler(self.file_handler)

    def has_console_handler(self) -> bool:
        return len([h for h in self.handlers if type(h) == logging.StreamHandler]) > 0

    def has_file_handler(self) -> bool:
        return len([h for h in self.handlers if isinstance(h, logging.FileHandler)]) > 0

    def disable_console_output(self) -> None:
        if not self.has_console_handler():
            return None
        self.removeHandler(self.stdout_handler)

    def enable_console_output(self) -> None:
        if self.has_console_handler():
            return None
        self.addHandler(self.stdout_handler)

    def disable_file_output(self) -> None:
        if not self.has_file_handler():
            return None
        self.removeHandler(self.file_handler)

    def enable_file_output(self) -> None:
        if self.has_file_handler():
            return None
        self.addHandler(self.file_handler)

    def _custom_log(self, func: Callable, msg: str, *args, **kwargs) -> Optional[Callable]:
        """Helper method for logging DEBUG through CRITICAL messages by calling the appropriate
        `func()` from the base class."""
        # Log normally if verbosity is on
        if self.verbose:
            return func(msg, *args, **kwargs)

        # If verbosity is off and there is no file handler, there is nothing left to do
        if not self.has_file_handler():
            return None

        # If verbosity is off and a file handler is present, then disable stdout logging, log, and
        # finally reenable stdout logging
        self.disable_console_output()
        func(msg, *args, **kwargs)
        self.enable_console_output()
        return None

    @caller_reader
    def debug(self, msg: str, *args, **kwargs):
        self._custom_log(super().debug, msg, *args, **kwargs)

    @caller_reader
    def info(self, msg: str, *args, **kwargs):
        self._custom_log(super().info, msg, *args, **kwargs)

    @caller_reader
    def warning(self, msg: str, *args, **kwargs):
        self._custom_log(super().warning, msg, *args, **kwargs)

    @caller_reader
    def error(self, msg: str, *args, **kwargs):
        self._custom_log(super().error, msg, *args, **kwargs)

    @caller_reader
    def critical(self, msg: str, *args, **kwargs):
        self._custom_log(super().critical, msg, *args, **kwargs)


def demo_verbose() -> None:
    print('*' * 80 + '\nVerbose logging (stdout + file)\n' + '*' * 80)
    verbose_log = CustomLogger('verbose', verbose=True, log_dir='logs')

    verbose_log.warning('We now log to both stdout and a file log')

    verbose_log.disable_file_output()
    msg = 'It should be color in a true TTY, but plain in a file'
    verbose_log.info("test info " + msg)
    verbose_log.debug("test debug " + msg)
    verbose_log.warning("test warning " + msg)

    verbose_log.enable_file_output()


def demo_quiet() -> None:
    print('*' * 80 + '\nQuiet logging (stdout: only file: all levels)\n' + '*' * 80)
    quiet_log = CustomLogger('quiet', verbose=False, log_dir='logs')
    quiet_log.warning('We now log only to a file log')
    quiet_log.info('Write info to a file log')


if __name__ == '__main__':
    demo_verbose()
    demo_quiet()
