import numpy as np
from itertools import repeat
import multiprocessing
from collections.abc import Iterable
from typing import Any, Callable, ClassVar, List, Dict, Union, Optional

from stml_mft_china_eq.pyutils.custom_logger import CustomLogger


def split_array_to_batches(
    arr_or_list: Union[List, np.ndarray],
    batch_size: Optional[int] = None,
    n_batch: Optional[int] = None
) -> List[np.ndarray]:
    """Split list/array into batches.

    Args:
        arr_or_list: the input to be split
        batch_size: int
        n_batch: int
    Note:
        Exactly ONLY ONE out of batch_size and n_batch should be validly input.
    Returns:
        list of np.ndarray
    """
    if (batch_size is None) == (n_batch is None):
        raise ValueError("Exactly ONLY ONE out of batch_size and n_batch should be validly input.")
    if batch_size is not None:
        n_batch = max(1, int(np.ceil(len(arr_or_list)/batch_size)))
    if (n_batch < 1) or (not isinstance(n_batch, int)):
        raise ValueError(f"Input n_batch={n_batch} must be a positive integer!")
    return np.array_split(np.stack(arr_or_list), n_batch)


def starmap_with_kwargs(pool, fn: Callable, args_iter: Optional[Iterable] = None, kwargs_iter: Optional[Iterable] = None):
    if bool(args_iter) is False and bool(kwargs_iter) is False:
        raise ValueError("At least one out of args_iter and kwargs_iter should be valid to settle the length")
    if args_iter is None or args_iter == list():
        args_iter = repeat([])
    if kwargs_iter is None or kwargs_iter == dict():
        kwargs_iter = repeat({})
    args_for_starmap = zip(repeat(fn), args_iter, kwargs_iter)
    return pool.starmap(apply_args_and_kwargs, args_for_starmap)


def apply_args_and_kwargs(fn, args, kwargs):
    return fn(*args, **kwargs)


def pool_map(func: Callable, args_iter: Optional[Iterable] = None, kwargs_iter: Optional[Iterable] = None, n_workers: int = 10, n_workers_error: Optional[int] = None, n_workers_warning: Optional[int] = None) -> Any:
    logger = CustomLogger(name="pool_map")
    if n_workers_error is None:
        n_workers_error = int(multiprocessing.cpu_count() / 2)
    if n_workers_warning is None:
        n_workers_warning = int(multiprocessing.cpu_count() / 3)
    if n_workers >= n_workers_error:
        raise ValueError(f"The number of n_workers={n_workers} is too high")
    if n_workers >= n_workers_warning:
        logger.warning(f"The number of n_workers={n_workers} is too high, will thre")
        n_workers = int(max(n_workers, multiprocessing.cpu_count()/3))

    with multiprocessing.Pool(processes=n_workers) as pool:
        res = starmap_with_kwargs(pool, func, args_iter=args_iter, kwargs_iter=kwargs_iter)
    return res
