import os
import shutil
import numpy as np
import pandas as pd
import pyarrow as pa
import feather
from typing import Any, Callable, ClassVar, List, Dict, Union, Optional
import datetime
from datetime import datetime as ddtime

import stml_mft_china_eq.pyutils.datetime_utils as dtu
from stml_mft_china_eq.configs import const


read_csv = pd.read_csv
path_exists = os.path.exists


def mkdirs(dirname: str) -> None:
    try:
        os.makedirs(dirname)
    except OSError:
        pass

# alias to mkdirs
makedirs = mkdirs

def rmdirs(dirname: str) -> None:
    if os.path.exists(dirname):
        try:
            shutil.rmtree(dirname)
        except OSError:
            pass


def rmmkdirs(dirname: str) -> None:
    """Clean a dir by rmdirs and mkdirs sequentially"""
    rmdirs(dirname)
    mkdirs(dirname)


# alias to .rmmkdirs
cleandirs = rmmkdirs


def listdir(dirname: str) -> List[str]:
    return os.listdir(dirname)


def all_files_exist(files: List[str]) -> bool:
    return bool(np.array([
        os.path.exists(f) for f in files
    ]).all())


def glob(s: str, do_sorted: bool = True) -> List[str]:
    from glob import glob as gglob
    return sorted(gglob(s)) if do_sorted else gglob(s)


def write_df(df: pd.DataFrame, filename: str, fmt: str = "feather", **kwargs) -> None:
    # use feather as the format to save
    if not isinstance(df, pd.DataFrame):
        raise ValueError("Input is not a pandas dataframe")
    if fmt not in ["csv", "hdf", "pickle", "feather", "parquet"]:
        raise NotImplementedError(f"Not supported format {fmt}")
    saver = getattr(df, f"to_{fmt}")
    params = {
        "csv": {"index": None},
        'hdf': {'key': 'data', 'format': 'table'},
        'pickle': {},
        'feather': {},
        'parquet': {'engine': 'pyarrow'},
    }[fmt]
    kwargs.update(params)
    saver(filename, **kwargs)

# alias to .write_df
save_df = write_df


def read_df(filename: str, fmt: str = "feather", **kwargs) -> pd.DataFrame:
    loader = feather.read_dataframe if fmt == 'feather' else getattr(pd, f'read_{fmt}')
    return loader(filename, **kwargs)



# alias to .read_df
load_df = read_df


def write_vdf(df: pd.DataFrame, filename: str, **kwargs) -> None:
    # choose feather for usage
    write_df(df, filename, fmt="feather", **kwargs)

# alias to .write_vdf
save_vdf = write_vdf


def write_daily_vdf(df: pd.DataFrame, dirname: str, dates: List[dtu.U_DATE], suffix: str = "", weekdays_only: bool = True, **kwargs) -> None:
    mkdirs(dirname)
    if weekdays_only:
        dates = [_ for _ in dates if dtu.is_weekday(_)]
    for date in dates:
        date_int = dtu.to_date_int(date)
        filename = os.path.join(dirname, "{0}{1}.vdf".format(date_int, suffix))
        if const.COL_DATE not in df.columns:
            df = dtu.df_add_time_labels(df)
        sub_df = df.loc[df[const.COL_DATE] == date_int].reset_index(drop=True)
        write_vdf(sub_df, filename, **kwargs)

# alias to .write_daily_vdf
save_daily_vdf = write_daily_vdf


def read_vdf(
    filename: str,
    start_datetime: Optional[dtu.U_DT] = None,
    end_datetime: Optional[dtu.U_DT] = None,
    col_timestamp: str = "timestamp",
    symbols_to_read: Optional[List[str]] = None,
    feat_cols_to_read: Optional[List[str]] = None,
    feat_names_to_read: Optional[List[str]] = None,
    **kwargs
) -> pd.DataFrame:
    """Read a vdf file within specified start/end datetime limit.

    Args:
        filename: str
        start_datetime: Optional[datetime.datetime], limit the output's min datetime if necessary. Default value None means no start datetime limit
        end_datetime: Optional[datetime.datetime], limit the output's max datetime if necessary. Default value None means no end datetime limit
        col_timestamp: str, the column of timestamp that indicate the UTC timestamp for time comparison
        symbols_to_read: Optional[List[str]], the list of symbols to get read from the file. Default=None means reading all symbols without constraints.
                           Examples: ["600601.XSHG", "600651.XSHG"], will be cons constructed to feat_cols_to_read
        feat_cols_to_read: Optional[List[str]], the list specifying the feature COLUMNS (besides time columns) to read in the file. Default=None means to read all columns.
                           Examples: [f"{symbol}/{feat_name}" for feat_name in feat_names for symbol in symbols]
        feat_names_to_read: Optional[List[str]], the list specifying the feature NAMES (besides time columns) to read in the file. Default=None means to read all columns.
                           Examples: ["OpenPrice", "ClosePrice", "LimitUD"], will be constructed in feat_cols_to_read
    """
    import stml_mft_china_eq.configs.const as conf_const
    # get feat_cols_to_read if it can be totally determined ahead, so that the reading speed is fast by sending args 'columns' to .read_df
    if feat_cols_to_read is not None:
        if (symbols_to_read is not None) or (feat_names_to_read is not None):
            raise ValueError("feat_cols_to_read is already valid. Don't input symbols_to_read and feat_names_to_read again to involve mistake risks")
        if conf_const.COL_TIMESTAMP not in feat_cols_to_read:
            feat_cols_to_read = [conf_const.COL_TIMESTAMP] + feat_cols_to_read
    else:
        if (symbols_to_read is not None) and (feat_names_to_read is not None):
            feat_cols_to_read = [f"{symbol}/{feat_name}" for feat_name in feat_names_to_read for symbol in symbols_to_read]
            feat_cols_to_read = [conf_const.COL_TIMESTAMP] + feat_cols_to_read

    # choose feather for usage
    df = read_df(filename, fmt="feather", columns=feat_cols_to_read, **kwargs)
    if start_datetime is not None or end_datetime is not None:
        df = ensure_df_sorted(df, col_timestamp=col_timestamp)
        if start_datetime is not None:
            start_timestamp = dtu.to_timestamp(dt_in=start_datetime)
            if start_timestamp > df.iloc[0][col_timestamp]:
                df = df.loc[df[col_timestamp]>=start_timestamp].reset_index(drop=True)
        if end_datetime is not None:
            end_timestamp = dtu.to_timestamp(dt_in=end_datetime)
            if end_timestamp < df.iloc[-1][col_timestamp]:
                df = df.loc[df[col_timestamp]<=end_timestamp].reset_index(drop=True)

    # postprocessing to get feat_cols_to_read
    if feat_cols_to_read is None:
        def _col_split(col):
            return col.split("/", 1)
        if (symbols_to_read is None) == (feat_names_to_read is None):
            # (1) if both None, nothing needs to be done here
            # (2) if both valid, feat_cols_to_read has been settled ahead before reading, so no entry to this condition and nothing needs to be done here
            feat_cols_to_read = list(df.columns)
        elif (symbols_to_read is None) and (feat_names_to_read is not None):
            feat_cols_to_read = [c for c in df.columns if (len(_col_split(c))==2) and (_col_split(c)[1] in feat_names_to_read)]
        elif (symbols_to_read is not None) and (feat_names_to_read is None):
            feat_cols_to_read = [c for c in df.columns if (len(_col_split(c))==2) and (_col_split(c)[0] in symbols_to_read)]

        # prefix time related columns if they are not included yet
        feat_cols_to_read = [c for c in conf_const.COLS_TIME if (c in df.columns) and (c not in feat_cols_to_read)] + feat_cols_to_read
        df = df[feat_cols_to_read]

    return df


# alias to .read_vdf
load_vdf = read_vdf

# def read_df_filter1(
    # filename: str,
    # mask,
    # columns,
    # **kwargs
# ):
    # loader = feather.read_dataframe
    # df = loader(filename, columns=columns, **kwargs)
    # return df[mask]

# def read_df_filter2(
    # filename: str,
    # mask,
    # columns,
    # **kwargs
# ) -> pd.DataFrame:
    # with pa.OSFile(filename, 'rb') as source:
        # df = pa.ipc.open_file(source).read_all().select(columns).filter(mask).to_pandas()
    # return df

# def read_df_filter3(
    # filename: str,
    # mask,
    # columns,
    # **kwargs
# ) -> pd.DataFrame:
    # with pa.memory_map(filename, 'r') as source:
        # df = pa.ipc.RecordBatchFileReader(source).read_all().select(columns).filter(mask).to_pandas()
    # return df


def batch_merge_daily_files(sorted_batch_daily_files: List[str], batch_merged_file: str, delete_daily_files: bool = False, **kwargs) -> None:
    """To be called by .merge_vdf_daily_to_ten_days"""
    df = pd.concat([
        read_vdf(_d_file, **kwargs) for _d_file in sorted_batch_daily_files
    ], axis=0).reset_index(drop=True)
    write_vdf(df, batch_merged_file)
    if delete_daily_files:
        for _d_file in sorted_batch_daily_files:
            os.remove(_d_file)

def clean_vdf_all_ten_days_files(dirname: str) -> None:
    # Clean ALL ten_days files in that directory
    ten_days_files = get_vdf_all_ten_day_files(dirname, output_fullpath=True)
    for ten_day_file in ten_days_files:
        os.remove(ten_day_file)

clean_ten_days_file = clean_vdf_all_ten_days_files


def clean_vdf_daily_files_that_have_ten_days_files(dirname: str, suffix: str = "") -> None:
    # Clean ALL daily files that have ten_days files in that directory
    all_daily_files = get_vdf_all_daily_files(dirname, suffix=suffix, output_fullpath=True)
    all_ten_days_files = get_vdf_all_ten_day_files(dirname, suffix=suffix, output_fullpath=True)

    d2t, t2d = {}, {}
    for d_file in all_daily_files:
        t_file = daily_file_to_ten_days_file(d_file)
        d2t[d_file] = t_file
        t2d[t_file] = t2d.get(t_file, []) + [d_file]

    for t_file in all_ten_days_files:
        daily_files_to_del = t2d.get(t_file, [])
        for d_file in daily_files_to_del:
            os.remove(d_file)

clean_daily_file = clean_vdf_daily_files_that_have_ten_days_files


def merge_vdf_daily_to_ten_days(dirname: str, n_workers: int = 10, start_date: Optional[dtu.U_DATE] = None, end_date: Optional[dtu.U_DATE] = None, suffix: str = "", overwrite: bool = True, delete_daily_files: bool = False) -> None:
    """Merge vdf files in a directory, from daily files to ten-days files.

    Args:
        dirname: str, the directory that will read and write on
        n_workers: positive int, n_workers>1: executed in parallel by a multiprocess.pool
                                 n_workers==1: executed in a sequential order.
                  Default n_workers = 10.
        start_date: start date the merge operation will search
        end_date: end date the merge operation will search
        suffix: str, to find files in YYYYMM*suffix.vdf. See get_vdf_files for details.
        overwrite: whether overwrite the original ten-days files.
        delete_daily_files: bool, whether or not delete the daily files to save space. Default is False.
    """
    from itertools import repeat
    from stml_mft_china_eq.pyutils.multiprocess import pool_map

    if n_workers <= 0 or not isinstance(n_workers, int):
        raise ValueError(f"The value of n_workers={n_workers} is incorrect, which should be positive integer")
    orig_daily_files, orig_ten_days_files = get_vdf_files_daily_and_ten_days(
        dirname=dirname, start_date=start_date, end_date=end_date, suffix=suffix,
    )

    d2t, t2d = {}, {}
    for d_file in orig_daily_files:
        t_file = daily_file_to_ten_days_file(d_file)
        d2t[d_file] = t_file
        t2d[t_file] = t2d.get(t_file, []) + [d_file]

    is_overlap = np.array([_ in t2d for _ in orig_ten_days_files])
    if is_overlap.any():
        ten_days_files_overlap = [orig_ten_days_files[i] for i in np.where(is_overlap)[0]]
        raise ValueError("There are some overlapping conflicts between existing daily files and ten days files: {}. Please fix them manually.".format(ten_days_files_overlap))

    resulted_ten_days_files = sorted(
        list(t2d.keys()) + list(orig_ten_days_files),
        key=lambda x: os.path.basename(x)[:7])
    if len(resulted_ten_days_files) <= 1:
        # nothing needs to be done
        return None
    # leave the last ten-days file unmerged, because it may not be ready full of days yet
    resulted_ten_days_files = resulted_ten_days_files[:-1]

    if n_workers > 1:
        # parallel
        args_iter = []
        for t_file in resulted_ten_days_files:
            if (not overwrite) and (t_file in orig_ten_days_files):
                continue
            local_d_files = sorted(t2d[t_file], key=lambda x: os.path.basename(x)[:8])
            args_iter.append([local_d_files, t_file])
        if len(args_iter) > 0:
            pool_map(
                batch_merge_daily_files,
                args_iter=args_iter,
                kwargs_iter=repeat({"delete_daily_files": delete_daily_files}),
                n_workers=n_workers
            )
    else:
        # n_workers==1, i.e., sequential
        for t_file in resulted_ten_days_files:
            if (not overwrite) and (t_file in orig_ten_days_files):
                continue
            local_d_files = sorted(t2d[t_file], key=lambda x: os.path.basename(x)[:8])
            batch_merge_daily_files(local_d_files, t_file, delete_daily_files=delete_daily_files)

write_ten_days_file = merge_vdf_daily_to_ten_days


def daily_file_to_ten_days_file(daily_filename: str) -> str:
    """Get the merged ten-days filename from the one-day filename
    Example:
        20210305.vdf -> 2021030.vdf
        20210331.vdf -> 2021032.vdf
    """
    dirname, basename = os.path.dirname(daily_filename), os.path.basename(daily_filename)
    date, extension = basename[:7], basename[8:]
    if date[-1] == '3':
        date = date[:-1] + '2'
    return os.path.join(dirname, date + extension)


def get_vdf_all_daily_files(dirname: str, suffix: str = "", output_fullpath: bool = False) -> List[str]:
    import re
    files = listdir(dirname)
    daily_regex = re.compile(r"^\d{8}" + suffix + '.vdf$')
    if output_fullpath:
        return sorted([os.path.join(dirname, f) for f in files if daily_regex.findall(f)])
    else:
        return sorted([f for f in files if daily_regex.findall(f)])

def get_vdf_all_ten_day_files(dirname: str, suffix: str = "", output_fullpath: bool = False) -> List[str]:
    import re
    files = listdir(dirname)
    ten_days_regex = re.compile(r"^\d{7}" + suffix + '.vdf$')
    if output_fullpath:
        return sorted([os.path.join(dirname, f) for f in files if ten_days_regex.findall(f)])
    else:
        return sorted([f for f in files if ten_days_regex.findall(f)])

def get_vdf_files_daily_and_ten_days(dirname: str, start_date: Optional[dtu.U_DATE] = None, end_date: Optional[dtu.U_DATE] = None, suffix: str = "", bool_include_overlapped_daily_files: bool = False) -> (List[str], List[str]):
    """Get two list of files, the first is a list of daily files, and the second is a list of tens of days files.
    Both start_date and end_date are INCLUSIVE in the loading process.

    Args:
        dirname: str
        start_date/end_date: the start/end date to constrain the file search
            Both start_date and end_date are INCLUSIVE in the loading process.
        suffix: YYYYMMDDsuffix.vdf and YYYYMMxsuffix.vdf
        bool_include_overlapped_daily_files: whether daily files that have been represented in ten-days files are included, default=False
    Returns:
        daily_files: list of daily files, e.g., ["20210203.vdf", "20210204.vdf"]
        ten_days_files: list of ten-days files, e.g., ["2021020.vdf", "2021021.vdf", "2021022.vdf", "2021030.vdf"]
    """
    start_date = dtu.to_date_int(start_date) if start_date else start_date
    end_date = dtu.to_date_int(end_date) if end_date else end_date

    daily_files = get_vdf_all_daily_files(dirname, suffix=suffix)
    ten_days_files = get_vdf_all_ten_day_files(dirname, suffix=suffix)
    if not bool_include_overlapped_daily_files:
        daily_files = [d for d in daily_files if daily_file_to_ten_days_file(d) not in ten_days_files]

    def _filter_daily_files(files: List[str], start_date: Optional[int] = None, end_date: Optional[int] = None) -> List[str]:
        files = [os.path.basename(f) for f in files]
        if start_date is not None:
            files = [str(f) for f in files if int(f[:8]) >= start_date]
        if end_date is not None:
            files = [str(f) for f in files if int(f[:8]) <= end_date]
        return files

    def _filter_ten_days_files(files: List[str], start_date: Optional[int] = None, end_date: Optional[int] = None) -> List[str]:
        def _get_ten_days_date(date: int) -> int:
            date = int(date//10)
            if date % 10 == 3:
                return int(10 * (date // 10) + 2)
            return date

        files = [os.path.basename(f) for f in files]
        if start_date is not None:
            files = [str(f) for f in files if int(f[:7]) >= _get_ten_days_date(start_date)]
        if end_date is not None:
            files = [str(f) for f in files if int(f[:7]) <= _get_ten_days_date(end_date)]
        return files

    daily_files = sorted(_filter_daily_files(daily_files, start_date, end_date))
    ten_days_files = sorted(_filter_ten_days_files(ten_days_files, start_date, end_date))
    daily_files = [os.path.join(dirname, f) for f in daily_files]
    ten_days_files = [os.path.join(dirname, f) for f in ten_days_files]
    return daily_files, ten_days_files


def get_vdf_files(dirname: str, start_date: Optional[dtu.U_DATE] = None, end_date: Optional[dtu.U_DATE] = None, suffix: str = "") -> List[str]:
    """Get list of files, either a list of daily files, or a list of tens of days files, or mix.
    Examples: 20200201.vdf
              2020021.vdf
              2020022blabla.vdf
    User needs to do further filtering based on the date columns like in .read_vdf_by_date.
    Both start_date and end_date are INCLUSIVE in the loading process.
    """
    daily_files, ten_days_files = get_vdf_files_daily_and_ten_days(
        dirname=dirname, start_date=start_date, end_date=end_date, suffix=suffix)
    files = sorted(daily_files + ten_days_files, key=lambda x: os.path.basename(x)[:8])
    return files


def read_vdf_by_date(
    dirname: str,
    start_date: Optional[dtu.U_DATE] = None,
    end_date: Optional[dtu.U_DATE] = None,
    col_timestamp: str = "timestamp",
    suffix: str = "",
    symbols_to_read: Optional[List[str]] = None,
    feat_cols_to_read: Optional[List[str]] = None,
    feat_names_to_read: Optional[List[str]] = None,
    **kwargs
) -> pd.DataFrame:
    """Read vdf file or directory by date.

    Args:
        dirname: str, directory name
        start_date, end_date: YYYYMMDD left right dates, both closed
            If either is input as None, default bounds 20000101--25000101 will be taken correspondingly
        col_timestamp: str, the column name of timestamp in the vdf file. Default: "timestamp".
        suffix: str, to find files in YYYYMM*suffix.vdf. See get_vdf_files for details.
        feat_cols_to_read: Optional[List[str]], passed to .read_vdf
        symbols_to_read: Optional[List[str]], passed to .read_vdf
        feat_names_to_read: Optional[List[str]], passed to .read_vdf

    Returns:
        pd.DataFrame

    Example usage:
        >>> df = utils.read_vdf_by_date("dirname", 20200305, 20200423)
    """
    if start_date is None:
        start_date = 20000101
    if end_date is None:
        end_date = 25000101
    start_date, end_date = dtu.to_date_int(start_date), dtu.to_date_int(end_date)
    if start_date > end_date:
        raise ValueError("Input start_date {0} > end_date {1}".format(
            start_date, end_date
        ))

    start_dateinterval = dtu.to_dateinterval_obj(date_in=start_date, interval_in=0)
    end_dateinterval = dtu.to_dateinterval_obj(date_in=end_date, interval_in=dtu.N_ARR_INTERVAL_STRS_IN_1DAY-1)
    dfs = [
        read_vdf(
            f,
            start_datetime=start_dateinterval,
            end_datetime=end_dateinterval,
            col_timestamp=col_timestamp,
            symbols_to_read=symbols_to_read,
            feat_cols_to_read=feat_cols_to_read,
            feat_names_to_read=feat_names_to_read,
            **kwargs
        )
        for f in get_vdf_files(dirname, start_date, end_date, suffix=suffix)
    ]

    if len(dfs) == 0:
        return pd.DataFrame()
    df = pd.concat(dfs, axis=0).reset_index(drop=True)
    df = ensure_df_sorted(df, col_timestamp=col_timestamp)
    return df

# alias to .read_vdf_by_date
load_vdf_by_date = read_vdf_by_date


def get_missing_vdf_dates(start_date: dtu.U_DATE, end_date: dtu.U_DATE, dirname: str, overwrite: bool = False, suffix: str = "", date_ranger: Optional[Callable] = None, **kwargs_date_ranger) -> List[int]:
    """Get list of dates where the ${date}.vdf is not in the given directory
    """
    import re
    if date_ranger is None:
        date_ranger = dtu.date_range_china_eq
    dates = [dtu.to_date_int(_) for _ in
             date_ranger(start_date, end_date, **kwargs_date_ranger)]
    if overwrite:
        return dates

    get_date = lambda x: dtu.to_date_int(os.path.splitext(x)[0].replace(suffix, ''))
    try:
        files = listdir(dirname)
        regex = re.compile(r"^\d{8}" + suffix + '.vdf')
        files = [f for f in files if regex.findall(f)]
        avail_dates = [get_date(f) for f in files]
        return sorted(list(set(dates) - set(avail_dates)))
    except Exception:
        return dates


def is_df_sorted(df: pd.DataFrame, col_timestamp: str = "timestamp") -> bool:
    return (df[col_timestamp].values[:-1] < df[col_timestamp].values[1:]).all()


def is_df_timestamp_duplicate(df: pd.DataFrame, col_timestamp: str = "timestamp") -> bool:
    return df[col_timestamp].duplicated().any()


def ensure_df_sorted(df: pd.DataFrame, check_duplicate: bool = True, col_timestamp: str = "timestamp") -> pd.DataFrame:
    if not is_df_sorted(df):
        df = df.sort(col_timestamp).reset_index(drop=True)
    if check_duplicate:
        if is_df_timestamp_duplicate(df):
            raise ValueError("Duplication exists in timestamp, it should be illegal. Please check the data.")
    return df


# some numerical downcast/upcast of dataframe before/after IO
def downcast_float_in_df(df: pd.DataFrame, target_type: str = "float32", bool_copy: bool = False) -> pd.DataFrame:
    colstypes = df.dtypes.reset_index().values
    list_type = ["float64", "float32", "float16"]
    list_type_to_check = list_type[:list_type.index(target_type)]

    list_col_to_downcast = []
    for col, coltype in colstypes:
        if "timestamp" in col:
            # keep timestamp unaffected
            continue
        if coltype in list_type_to_check:
            list_col_to_downcast.append(col)
    if len(list_col_to_downcast) > 0:
        if bool_copy:
            df = df.copy()
        for col in list_col_to_downcast:
            df[col] = df[col].astype(target_type)
    return df

def upcast_float_in_df(df: pd.DataFrame, target_type: str = "float64", bool_copy: bool = False) -> pd.DataFrame:
    colstypes = df.dtypes.reset_index().values
    list_type = ["float16", "float32", "float64"]
    list_type_to_check = list_type[:list_type.index(target_type)]

    list_col_to_upcast = []
    for col, coltype in colstypes:
        if col == "timestamp":
            continue
        if coltype in list_type_to_check:
            list_col_to_upcast.append(col)
    if len(list_col_to_upcast) > 0:
        if bool_copy:
            df = df.copy()
        for col in list_col_to_upcast:
            df[col] = df[col].astype(target_type)
    return df


# json
def read_json(filename: str, **kwargs) -> Dict:
    """Read json file to dict.
    NOTE: we have to use double quotes " rather than single quotes ' in text json file.
    """
    import json
    with open(filename, "r") as f:
        res_dict = json.loads(f.read())
    return res_dict

# alias to .read_json
load_json = read_json

def write_json(input_dict: Dict, filename: str, indent: int = 4, sort_keys=False, **kwargs) -> None:
    """Dump a dict into json format file"""
    import json
    tmp_dict = {}
    for k, v in input_dict.items():
        if isinstance(v, np.ndarray):
            tmp_dict[k] = list(v)
        else:
            tmp_dict[k] = v
    with open(filename, "w") as f:
        json.dump(tmp_dict, f, indent=indent, sort_keys=sort_keys)

# alias to .write_json
save_json = write_json


def write_pickle(obj, filename: str, **kwargs) -> None:
    import pickle
    with open(filename, "wb") as f:
        pickle.dump(obj, f)

def read_pickle(filename: str, **kwargs) -> None:
    import pickle
    return pickle.load(open(filename, "rb"))
