import json
import argparse
from collections import OrderedDict

from typing import Any, Callable, ClassVar, List, Dict, Union, Optional

class Required:
    required = True

def identity(x: Any) -> Any:
    return x

def str2bool(x: str) -> bool:
    x = x.lower()
    if x in ['true', '1', 't', 'y', 'yes']:
        return True
    elif x in ['false', '0', 'f', 'n', 'no']:
        return False
    raise ValueError("Unrecognized string={} for str2bool".format(x))


class CustomAction(argparse.Action):
    def __init__(self, transform_func, *args, **kwargs):
        """Argparse custom action.

        Args:
            transform_func: the transform function
        """
        self._transform_func = transform_func
        super(CustomAction, self).__init__(*args, **kwargs)

    def __call__(self, parser, namespace, value, option_string):
        value = self._transform_func(value)
        setattr(namespace, self.dest, value)



class LoadJsonConfig(argparse.Action):
    def __call__ (self, parser, namespace, values, option_string=None):
        with values as f:
            data = json.loads(f.read())

        for k, v in data.items():
            # set arguments in the target namespace if they haven’t been set yet
            if getattr(namespace, k, None) is None:
                setattr(namespace, k, v)

def parse_args(dict_options: Dict, description: str = "") -> argparse.Namespace:
    if not isinstance(dict_options, (Dict, OrderedDict)):
        raise ValueError("Input dict_options should be in dict format")
    parser_json = argparse.ArgumentParser(description=description+"_json", add_help=False)
    parser_json.add_argument(
        '-c',
        '--config_json_file',
        required=False,
        type=open,
        action=LoadJsonConfig,
    )
    args, left_argv = parser_json.parse_known_args()

    parser = argparse.ArgumentParser(description=description, parents=[parser_json])
    for key_arg, val_arg in dict_options.items():
        if len(val_arg)!=2:
            print(key_arg, val_arg)
            raise ValueError("Each item of args should be in format of 'key: (default, transform_func)'")
        default, transform_func = val_arg

        if key_arg in args:
            # already read in json file
            setattr(args, key_arg, transform_func(getattr(args, key_arg)))
            continue

        if default == Required:
            parser.add_argument(
                '--{}'.format(key_arg),
                required=True,
                action=CustomAction,
                transform_func=transform_func,
            )
        else:
            parser.add_argument(
                '--{}'.format(key_arg),
                default=default,
                action=CustomAction,
                transform_func=transform_func,
            )
    args = parser.parse_args(left_argv, args).__dict__

    return args

